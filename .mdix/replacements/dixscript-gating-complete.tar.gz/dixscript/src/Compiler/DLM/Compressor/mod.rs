//! Compressor — data compression modules.
//! All three compressors are pure Rust and build on every target:
//! wasm32-unknown-unknown, wasm32-wasip2, Android, iOS, Windows.
//!
//! Gzip:  flate2 rust_backend (miniz_oxide)  — always pure Rust.
//! Bzip2: bzip2 0.6+ via libbz2-rs-sys       — pure Rust since June 2025.
//! LZMA:  lzma-rust2 (ported from tukaani xz-for-java) — pure Rust, real
//!        encoder (not the lzma-rs "dumb" literal-only placeholder encoder).
//!        `optimization` feature intentionally off, see Cargo.toml.

mod compressor_trait;
#[cfg(feature = "dlm-compressor")]
mod gzip_compressor;
#[cfg(feature = "bzip2-support")]
mod bzip2_compressor;
#[cfg(feature = "xz-support")]
mod lzma_compressor;

pub use compressor_trait::{ICompressor, CompressorResult};
#[cfg(feature = "dlm-compressor")]
pub use gzip_compressor::{GzipCompressor, CompressionLevel};
#[cfg(feature = "bzip2-support")]
pub use bzip2_compressor::Bzip2Compressor;
#[cfg(feature = "xz-support")]
pub use lzma_compressor::LzmaCompressor;
