# Changelog

All notable changes to the `dixscript` crate are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
versioning follows [Semantic Versioning](https://semver.org/).

For a snapshot of the *current* public API shape (not a log of changes to
it), see [`APICATALOG.md`](./APICATALOG.md) instead.

This covers the `dixscript` core crate only. The CLI (`mdix-cli`), FFI
bindings, and per-language wrappers (WASM/Python/C#/Go/Java/Lua/PHP) are
separate, independently-versioned packages in this same workspace with
their own release history.

## [2.0.0] — Unreleased

Breaking release.

### Added

- **`DixLoader::compile_to_document` and `compile_to_document_from_str`** return the arena `Document`
  that the compile pipeline builds: the enhanced `@QUICKFUNCS` section, the resolved `@DATA` with its
  numeric arrays homogenized, the `@ENUMS` section with the imported enums the data referenced, and
  every other section as parsed. `compile_to_resolved_ast` and `compile_to_resolved_ast_from_str`
  are these two followed by one `export`, and return what they always did.
- **`ValueResolver::with_document_product(&mut Document)`** makes the document the result of value
  resolution: the resolved data stays in its arena, the imported enums are merged into its `@ENUMS`,
  no owned data is exported and `ValueResolutionResult::resolved_ast` is `None`. `with_document` and
  `new` behave as before.
- **`homogenize_document` and `homogenize_document_data`** run the numeric-array pass over a
  `Document`'s data (or a `DocData` and its arena) and report whether anything changed.
  `homogenize_data_section` is the same walk behind the owned signature.
- **`Compiler::AST::arena`**, an index arena for the `Value`, `Expression` and
  `QuickFuncStatement` family: `Arena`, the node types `ValueNode`, `ExprNode` and `StmtNode`
  (40, 48 and 48 bytes, against 144, 160 and 384 for the owned types), and lossless
  `import_*` and `export_*` between an owned tree and the arena, and the handles `ValueRef`,
  `ExprRef` and `StmtRef` (`Arena::value_ref` and friends) whose `Display` and `Debug` print
  exactly what the owned types print and whose `==` compares trees structurally, across
  arenas. `arena::Document` is the arena-resident form of a whole `DixScript`
  (`Document::from_owned`, `Document::export`, structural `==`), with `Doc*` twins of the five
  sections that hold values, each with its own `from_owned` and `export`. `Arena::alloc_value_list`,
  `alloc_expr_list`, `alloc_prop_list`, `alloc_stmt_list`, `alloc_str_list` and `alloc_case_list`
  store a run of ids (or names, or cases) for a parser that builds a list node by node, and
  `alloc_case` stores a switch's default case. `Arena::append` copies one arena onto the end of another and returns an `ArenaOffsets`, which the `shifted` method of each `Doc*` section applies to move the section with it. `GeneralParser::parse_document` parses a file into one `Document` by appending the arenas of the section parsers in source order, and each section parser has `parse_section_doc` and `into_arena` for it. `GeneralParser::parse` is `parse_document` followed by one export. `Document` implements
  `Display`, and `Arena::display` pairs a `Doc*` section with its arena as an `ArenaDisplay` that
  prints; both print exactly what the owned types print. All five section parsers (`@SECURITY`, `@RAW`, `@SCHEMA`, `@DATA` and `@QUICKFUNCS`) build their values in an arena and export the finished section,
  with their public interfaces unchanged; the rest of the compiler still uses the owned types. It
  is the first piece of the arena AST described in `docs/dixscript/arena-ast.md`.
- **`GeneralSemanticAnalyzer::with_document`**, which gives the analyzer the arena form of the file it
  is analyzing, and **`RawSectionAnalyzer::analyze_doc`**, which checks `@RAW` blocks through an
  `Arena`. `DocRawBlock::id` and `DocRawBlock::format` read a block's `meta_data` as
  `RawBlock::id` and `format` do. The `@RAW` analyzer is the first consumer to read a `Document`;
  `DixLoader` parses into one and passes it to the analyzer. Diagnostics are unchanged, and
  `RawSectionAnalyzer::analyze` keeps its signature.
- **`SecuritySectionAnalyzer::analyze_doc`** and **`SchemaSectionAnalyzer::analyze_doc`**, which check
  `@SECURITY` and `@SCHEMA` (with the `@DATA` section it constrains) through an `Arena`, and
  **`DocSchemaField::path_string`**. `GeneralSemanticAnalyzer::with_document` now covers these two
  sections as well as `@RAW`. `analyze` and `SchemaSectionAnalyzer::validate_resolved` keep their
  signatures and copy their input into a scratch arena, so `DixLoader`'s post-resolution schema check
  copies the resolved `@DATA` section. Diagnostics are unchanged.
- **`DataSectionAnalyzer::analyze_doc`**, which checks `@DATA` through an `Arena`, and the four arena
  entry points of `TypeInferenceVisitor` (`infer_type_from_value_id`, `infer_type_from_expression_id`,
  `infer_element_type_from_value_id` and `infer_element_type_from_expression_id`), which give the
  answers of their owned twins for the same tree. `Arena::value_ids`, `expr_ids` and `stmt_ids` visit
  every node. `GeneralSemanticAnalyzer::with_document` now covers `@DATA` as well, and
  `DataSectionAnalyzer::analyze` keeps its signature. Diagnostics, indexes and symbol table entries
  are unchanged.
- **`QuickFuncsSectionAnalyzer::analyze_doc`**, which checks `@QUICKFUNCS` through an `Arena`, and the
  arena entry points of the call collector and the cycle detector (`FunctionCallCollector::analyze_function_doc`,
  `CycleDetectionValidator::validate_function_calls_doc` and `get_execution_order_doc`).
  `GeneralSemanticAnalyzer::with_document` now covers `@QUICKFUNCS` as well, and the owned entry points
  keep their signatures. Diagnostics, qualified identifier resolutions and registered functions are unchanged.
- **`QuickFunctionsAstEnhancer::enhance_doc`**, which enhances `@QUICKFUNCS` through an `Arena`
  (parameter defaults and qualified identifier resolution), the arena entry points of the resolver
  (`QualifiedIdentifierResolver::resolve_statement_list`, `resolve_statement_id` and
  `resolve_expression_id`), and `GeneralAstEnhancer::with_document`, which makes the enhancer read the
  `@QUICKFUNCS` section from a `Document` and copy only the enhanced section into the tree it returns.
  The owned entry points (`QuickFunctionsAstEnhancer::enhance`, `QualifiedIdentifierResolver::resolve_statement`,
  `resolve_statements` and `resolve_expression`, and `GeneralAstEnhancer::enhance` without a document)
  keep their signatures and give the same result. `TypeSystemManager::synthetic_parameter_default` is the
  default `apply_defaults_to_parameters` gives a typed parameter, now shared with the arena enhancer.
  The loader keeps the `Document` through stage 6 and passes it to the enhancer.
- **`TypeInferenceVisitor`'s owned entry points are wrappers.** `infer_type_from_value`,
  `infer_type_from_expression`, `infer_element_type_from_value` and `infer_element_type_from_expression`
  keep their signatures and results, and now copy their argument into a scratch arena and call the
  `_id` entry points. The code that walked the owned tree is gone, and the public items of
  `type_inference_visitor.rs` have rustdoc with examples.
- **`GeneralSemanticAnalyzer::with_document` now covers `@IMPORTS`, `@ENUMS` and `@DLM`** as well, so
  every section the analyzer looks at is read from the document when one is attached. They are the same
  owned types in both trees, so the results do not change for a file the loader produces. For a
  document and an owned tree that disagree, the `@DLM` of the document decides whether an encryptor
  needs a `@SECURITY` section.
- **`ImportsResolver` parses each imported file to a `Document`** and gives it to the semantic analyzer
  and the enhancer, as the loader does for the main file. Its entry points keep their signatures and
  results; `resolve_imports`, which takes trees the caller parsed, still analyzes them through the owned
  entry points.
- **`VersionConstraints::validate_script_doc(&Document)`** validates a file held as a `Document` and gives
  the same result as `validate_script` for it; the orchestrator's version phase calls it when a document is
  attached. `TypeSystemManager::validate_doc_quick_function_signature` is the arena form of the signature
  check.
- **`ValueResolver::with_document(&mut Document)`** gives the first three phases of value
  resolution (enum pre-resolution, the data context and the call finder) the document the file was
  parsed into. They then read the document's `@DATA` in its arena instead of a copy of the owned data
  section, and the loader passes the document it already holds. Without one, `ValueResolver::new` and
  the other constructors work as before, and the owned data is copied once for the three phases.
- **`ASTWalker::find_all_in(&Arena, &DocData)`** is the arena entry of the call finder.
  `find_all(&DataSection)` stays and copies the section into a scratch arena.
- **Quickfunction execution reads the arena.** `FunctionInterpreter::register_functions(&mut self,
  &mut Arena, &[QuickFunction])` copies the functions it can call (the local ones and every function
  of every imported namespace) into the arena once, and `execute_data_call` runs a call found in
  `@DATA` with the arena and the call's argument list. `execute` takes the already evaluated
  arguments as `CallArgs { values, wrap, position }`; `Wrap::Data` and `Wrap::Body` name the two
  conversions the two call paths always used (a tuple stays a tuple, cut to six items, or becomes an
  array). `DocQuickFunction::from_owned(&mut Arena, &QuickFunction)` copies one function in, and
  `ExecutionContext::with_capacity` sizes the root scope.


### Removed
- `VersionConstraints::with_forward_compat`, `is_valid_value_type`, `is_valid_default_value`,
  `is_valid_type_annotation`, `requires_advanced_mode`, `is_valid_function_type`,
  `is_valid_static_method_call`, `is_valid_instance_method_call`, `is_valid_dix_function_call`,
  `validate_quick_function_signature` and `validate_data_entry`. None had a caller in the workspace;
  `is_valid_type_annotation` returned true for any argument.
- `VersionManager::validate_script_features`, `supports_feature_control`, `supports_dual_parsers`,
  `get_recommended_parser` and `get_current_version` (use `current_version`).
- `ValidationResult::warnings` and `detected_version`, which nothing ever set.
- **`DCompressor.bzip2` and `DCompressor.lzma`.** gzip is the only DLM
  compression codec. The `bzip2` and `lzma-rust2` dependencies are gone
  (10 fewer crates in the default build). A file that names either codec
  now fails analysis with a `DLM004` "no longer supported" error, and a key
  file that records one fails to decompress with the same kind of message.
  The `bzip2-support` and `xz-support` Cargo features are removed too, so a
  `features = [...]` list that names either one no longer resolves. Files
  written by 1.0.0 with these codecs can still be read with 1.0.0.
- `binary_serialization_benchmark` compares gzip only.
- Three private functions of `ValueResolver` that nothing called, `resolve_call_arguments`,
  `resolve_expr_to_dix` and `resolve_value_to_dix` (about 240 lines).
- The owned `try_value_to_dix` of `ValueResolver` (private, about 110 lines), replaced by the arena
  version in `data_context.rs`.
- `ValueResolutionResult::original_ast` (a public field, so a breaking change): the clone of the whole
  AST that `ValueResolver::resolve` took before it started. Nothing in the workspace read it.
- The owned write-back of `ValueResolver` (nine private functions, 250 lines: the index of call
  positions, the path and search helpers and `value_position`), replaced by the arena version in
  `write_back.rs`.
- The owned phase 5 of `ValueResolver` (334 lines: the identifier walk over entries and values),
  replaced by the arena version in `identifier_resolution.rs`.
- `ResolutionRecord::arguments` (a public field, so a breaking change): the `Debug` text of each
  argument expression, built for every call attempt and read by nothing in the workspace.
- `FunctionRegistry` (a map of function definitions that nothing built or read; it was only
  re-exported) and `ValueResolver::convert_dix_value_to_value` (a public function; the resolver no
  longer turns results into literal nodes to pass them to the interpreter). The copy of a function's
  whole tree that the interpreter took for every call, and the one `unsafe` pointer cast in the
  interpreter, are gone with them.


### Performance

- **The loader without the owned tree.** Callgrind, debug build, instructions, `elements_database.mdix`,
  against the entry below (the document product alone): `compile_to_resolved_ast` 1,384,068,710 to
  1,332,499,315 (-3.73 percent), `load_text` 2,050,106,154 to 1,969,093,730 (-3.95), compile, pack and
  unpack 1,803,266,881 to 1,751,758,423 (-2.86) and compile and convert 2,185,142,582 to
  2,133,261,786 (-2.37). Against the tree before either change (the four figures of the entry
  below, first column) that is -3.38, -3.71, -2.60 and -2.14 percent. In the first run the saving is
  the export after the parse (20.8M), the enhancer's copy of the main file's tree (15.5M) and the
  drops of the two owned trees that no longer exist (15.4M), 51.7M against 51.6M measured; the
  other 29.4M of `load_text` is the clone in `determine_dlm_behavior` (18.2M, down to 753
  instructions) and the drop of the clone (about 10M), with 0.6M in `DixData::from_ast`. Release builds,
  wall-clock time and the files that are not this one were not measured.
- **Imported files in the arena.** The same measurement against the entry above: `compile_to_resolved_ast`
  1,332,499,315 to 1,327,400,148 (-0.38 percent), `load_text` 1,969,093,730 to 1,964,519,408 (-0.23),
  compile, pack and unpack 1,751,758,423 to 1,747,178,820 (-0.26) and compile and convert
  2,133,261,786 to 2,128,736,010 (-0.21): the exports of the four imported files (1.8M), the
  enhancer's clones of them (1.3M) and the owned trees they left (1.3M). Against the tree before the
  document became the product the four are -3.75, -3.94, -2.85 and -2.35 percent.
- **The loader's document product, measured alone.** Callgrind, debug build, instructions,
  `elements_database.mdix` (the largest corpus file), before against after: `compile_to_resolved_ast`
  1,379,063,569 to 1,384,068,710 (+0.36 percent), `load_text` 2,045,040,003 to 2,050,106,154 (+0.25),
  compile, pack and unpack 1,798,519,641 to 1,803,266,881 (+0.26) and compile and convert
  2,180,013,393 to 2,185,142,582 (+0.24). The resolver no longer exports the resolved data into an
  owned tree (32.1M instructions) and the document's own export at the end takes about the same
  share back; the difference is the arena homogenizer, 6.87M against 1.86M for the owned one in a
  debug build. The export at stage 4, the clone the enhancer makes and the owned tree the resolver
  still takes are what a later change removes. Release builds, wall-clock time and peak memory were
  not measured.
- Lambdas no longer copy their whole definition (body, statements and captured variables) every
  time they are called or passed: the interpreter shares the registry entry. A generated script of
  500 calls with block-bodied lambdas runs 18.7 percent fewer instructions and one of 3,000 calls with
  larger lambdas 29.1 percent fewer (debug build, prepare and resolve); a script with a few lambdas
  gains about 2 percent, and one with none is unchanged.
- Value resolution no longer builds a `Debug` string for every argument of every call it records: the
  whole pipeline (debug build, prepare and resolve) is 5.6 percent cheaper on the largest corpus file,
  4.1 to 4.6 percent on two others, and unchanged on files with few calls.
- Value resolution's remaining-identifier pass no longer builds a formatted path string and clones an
  entry for every node it visits: on the largest corpus file its cost fell from about 146M to 16M
  instructions, and the whole pipeline (debug build, prepare and resolve) is 2.3 to 9.8 percent
  cheaper than before the arena migration of value resolution on the five files measured.
- **Parser reservations are capped.** The section parsers sized the Vec for every nested
  call argument list, array, object and statement block from the length of the whole token
  stream. Those reservations are now capped at 16 elements; the one vector that holds a
  whole section keeps its full estimate. Compiling `elements_database.mdix` (445 KB)
  requests 159 MB instead of 7.50 GB, and its parse stage takes about 30 to 45 percent
  less time. Output is unchanged. A new test, `parser_alloc_budget`, guards the figure.

- **Value resolution is linear in the number of resolved calls.** Writing each resolved
  call back into the data tree searched the whole tree for the call's position, so a 4x
  larger input took 16x as long in that step. Positions are now indexed once. Compiling
  `elements_database.mdix` (445 KB, debug mode off) takes about a third of the time it did,
  and a 32x scaled input takes about a sixth. Output is unchanged. A new test,
  `value_resolution_scaling`, guards the growth rate.
- Calling a quickfunction no longer copies the function's whole tree and drops the copy: the functions
  are copied into the arena once and a call takes a pointer. On the largest corpus file, whose 2,596
  calls are all calls of imported functions, the whole pipeline (debug build, prepare and resolve,
  callgrind instruction counts) is 6.6 percent cheaper, and the call path itself 32 percent; on
  two other corpus files 9.4 and 3.8 percent. The three generated lambda scripts run 2.8, 15.3 and 14.2
  percent fewer instructions on top of the earlier sharing of lambda entries, and the two smallest
  files are unchanged. A script's execution scopes are sized for their parameters, and an object literal
  is built directly in the map the value holds. Release builds, wall-clock time and peak memory were
  not measured.


### Changed

- **The loader keeps its `Document` to the end of the pipeline.** Stage 6 stores the enhanced
  `@QUICKFUNCS` section back into it, stage 7 resolves `@DATA` in it and merges the imported enums into
  its `@ENUMS` (`with_document_product`), and stages 8 and 9 (numeric-array homogenization and the
  `@SCHEMA` check of the resolved data) read its own arena instead of copying the resolved data into
  a scratch arena. `compile_to_resolved_ast` returns the export of that document; its result, errors
  and log lines are unchanged on all 84 corpus files and on the crafted sources. On the largest corpus
  file this step alone was 0.24 to 0.36 percent more instructions in a debug build; the next entry
  removes that and more (see Performance).
- **The loader builds no owned tree before its last stage.** The export of the parse result is gone:
  stage 5 is given an empty owned tree next to the document (the analyzer reads every section from
  the document), stage 6 enhances the document in place (`enhance_document`, crate private: no copy
  of an owned tree and no export of the section), and stage 7 resolves through the crate-private
  `ValueResolver::for_document`, which registers the local functions from the document's own
  enhanced `@QUICKFUNCS` section without copying them. The public constructors and `enhance` are
  unchanged. `ValueResolver::with_document_product` now reads no owned tree at all (it read the
  `@QUICKFUNCS` section of one): the owned tree passed to it is ignored, which narrows what the
  method does since the previous entry; nothing but the loader calls it.
- **Imported files stay in the arena.** The imports resolver keeps the `Document` it parses for each
  imported file as the file's only tree: it no longer exports an owned tree from it, attaches the
  config to that tree or lets the enhancer clone it. The nested imports and the seed namespaces are read
  from the document, the enhancer works in place, and only the enhanced `@QUICKFUNCS` section and the
  `@ENUMS` section are taken out of the document, because a namespace holds them as owned types.
  `resolve_imports` still takes caller-parsed owned trees. No signature changed.
- **`load_text` and the other loads no longer clone the resolved tree** before looking for a `@DLM`
  section: `determine_dlm_behavior` takes the tree by value and moves it into its result, and copies
  it only on the path that has to change a copy.
- **The comment at stage 8 of the loader is corrected.** A hand-written array of mixed numeric
  literals does not reach the homogenizer: semantic analysis rejects it, so only arrays a function
  computed are promoted.
- **Enum pre-resolution runs on the arena.** The first phase of value resolution, which checks every
  enum reference in `@DATA` and turns the ones inside expressions into integers, has one
  implementation over the arena (`ValueResolution/enum_resolution.rs`) in place of the owned walker of
  about 890 lines. The result, the errors and the log lines are unchanged. Data with no enum
  expression is no longer rebuilt, and a whole-pipeline instruction count is 0.3 to 4.4 percent
  lower on the five files measured. The loader now keeps its `Document` until stage 7 is done.
- **The data context and the call finder run on the arena.** The second and third phases of value
  resolution read the arena (`ValueResolution/data_context.rs` and `ast_walker.rs`) in place of the
  owned tree. The context, the calls found and every log line are unchanged. The alias pass no longer
  clones the whole data section, and the whole-pipeline instruction count is a further 0.2 to 0.7
  percent lower on the same five files.
- **The last two phases of value resolution run on the arena.** The write-back of results (phase 4,
  `ValueResolution/write_back.rs`) allocates each result and a copy of each array, object and
  constructor on the way to it, and shares the rest; the remaining identifiers (phase 5,
  `ValueResolution/identifier_resolution.rs`) are resolved the same way, with the path of an
  identifier built only when it resolves. With a document attached both read and rewrite the
  document's data, which holds the results afterwards; the owned data section is replaced by one
  export at the end, only when a phase changed the data or the owned tree had none. Results, errors,
  the history of calls and every log line are unchanged, quirks included (a node that shares a
  position with a call takes its result, a call whose position no node has is not written, a nested
  array that held a resolved identifier comes back as a plain array).
- **Language version 2.0.0.** `@CONFIG` `version -> "2.0.0"` is now a recognized
  language version. Before, the version manager accepted the string but treated the
  file as 1.0.0. 1.0.0 files still load. The two versions differ only in the DLM
  codecs: bzip2 and lzma are valid in 1.0.0 and invalid in 2.0.0, where the version
  check says they were removed. `VersionManager::is_compatible_with` now means "can
  read files up to that version", and `get_version_constraints` gains a
  `RemovedDLMModules` entry. The defaults (`OperationalSettings`, the config schema
  and the manager's fallback) stay at 1.0.0 for now.
- **Minimum supported Rust version is 1.75** (was 1.85). The crate and its tests build
  and pass on Rust 1.75.0. Four code changes made that possible: `std::sync::LazyLock`
  is replaced by a small `Lazy` type on `OnceLock`, two `Option::is_none_or` calls
  became `map_or(true, ..)`, one `Result::inspect_err` became `map_err`, and a
  temporary-lifetime pattern in `Runtime/format_options.rs` that only Rust 1.79 and
  later accepts was rewritten. The repository's `Cargo.lock` pins seven dependencies
  below their newest versions to stay inside 1.75.
- **Quickfunction execution and call discovery work on the arena.** Breaking for anyone who built a
  `FunctionInterpreter` or read a `FunctionCallInfo`: the interpreter's constructors no longer take the
  quickfunction list (`register_functions` does that work, once); `find_function` returns
  `Option<&DocQuickFunction>`; `LambdaAst` holds arena handles (`params: StrList`, `body: ExprId`,
  `statements: StmtList`) with its captured variables; `FunctionCallInfo.arguments` is an `ExprList`
  into the arena the call was found in, and `ASTWalker::find_all` returns the calls together with the
  scratch arena they point into. The language server's use of `ValueResolver::new` is unchanged. A
  script resolves exactly as before: the corpus, the crafted and the hand-built inputs give the same
  results, history and logs through every entry point.


## [1.0.0] — 2026-07-21

### Added

- **Language & compiler pipeline** — full tokenize → parse → semantic
  analysis → AST enhancement → value resolution → array homogenization
  pipeline for the `.mdix` format: `@CONFIG`, `@IMPORTS` (local + cloud),
  `@ENUMS`, `@QUICKFUNCS` (compile-time expression evaluation), `@DATA`
  (flat properties, tables, group arrays, nested objects), `@SECURITY`.
- **Runtime data access** — `DixLoader` for loading from disk, string, or
  encrypted bytes; `DixData` for O(1) flattened dotted-path reads;
  `DixValue` covering every DixScript type.
- **Struct (de)serialization** — `DixSerialize`/`DixDeserialize` traits
  for converting between `DixData` and plain Rust structs without an
  intermediate hashmap.
- **Format conversion** — `DixConverter` for DixScript ⇄ JSON ⇄ TOML ⇄
  `HashMap<String, DixValue>`, in both directions.
- **DLM (Data Lifecycle Modules)** — compression (gzip/bzip2/lzma, all
  pure Rust) and encryption (AES-256-GCM, ChaCha20-Poly1305) applied at
  compile time via `@DLM(...)`, reversed at load time via `DixLoader`'s
  encrypted-load path. Keyfile and password (Argon2id-derived) modes.
- **Auditing** — `@DLM(DAuditor...)` DIY and Enhanced auditors, producing
  append-only `.mdix.au` compilation history alongside the compiled
  output. Native filesystem backend and browser `localStorage` backend
  (wasm32), selected automatically per target.
- **AST-level merge** — `MdixMerger` for merging multiple DixScript
  sources with weight-based (`WeightedPriority`, `PrimaryWins`,
  `SecondaryWins`) or strict (`ThrowOnConflict`) conflict resolution,
  configurable per-section and per-array-strategy.
- **Schema validation** — `SchemaBuilder`/`ValidationReport` for
  fluent, non-panicking runtime validation of a loaded `DixData` against
  an expected shape, collecting every violation rather than failing fast.
- **Querying** — `DixQuery`, LINQ-style chaining (`where_`, `order_by`,
  `select`, ...) over array fields and `GroupArray`s, plus
  wildcard-pattern queries across sibling paths.
- **Hot reload** — `HotReloadWatcher`, a poll-based file-change watcher
  for Rust consumers driving a game loop or tick.
- **Builder API** — `DixDataBuilder` and friends for constructing
  `DixData` (or writing a `.mdix` file directly) without a template file.
- **Source-text tooling** — `DixCompactor` for minifying/compacting
  `.mdix` source (token-based, not regex) and stripping comments.
- **Cross-platform** — builds on native (Linux/macOS/Windows/Android/iOS)
  and `wasm32-unknown-unknown`; every optional compression/encryption
  backend is pure Rust with no native C linking anywhere in the default
  feature set.
- **Error handling** — `ErrorManager` with per-instance isolated state,
  phase-classified errors (`DixError` over eleven compilation/runtime
  phases) with severity levels, plus `DiagnosticDumper` for standalone
  diagnostic reports.
