// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/dixscript/compiler.md, section "Compiler/Core/ValueResolution/function_interpreter.rs"
// ============================================================================
//! Executes QuickFunction bodies at compile time.
//!
//! The interpreter walks the arena AST. It never owns a syntax tree: the arena it reads is
//! passed into every call, and function bodies, lambdas and the arguments of a call are ids of
//! nodes in it. Before the first call [`FunctionInterpreter::register_functions`] copies the
//! functions it can call into that arena once, so a call costs no copy of its function.
//!
//! Parameter threading eliminates mutable field swapping. DebugConfig is
//! cached on construction - format!() is never evaluated when debug is off.
//! All errors are typed InterpreterError variants. Recursion depth has both
//! absolute and dynamic limits.

use std::cell::RefCell;
use std::collections::HashMap;
use std::rc::Rc;

use crate::Utilities::RustcHash::FxHashMap;

use crate::Builtins::Core::{DixType, DixValue};
use crate::Builtins::Resolver::builtin_call_resolver;
use crate::Compiler::AST::arena::{
    Arena, CaseId, CaseList, DocQuickFuncParam, DocQuickFunction, ExprId, ExprList, ExprNode,
    PropList, StmtId, StmtList, StmtNode, StrList, ValueId, ValueList, ValueNode,
};
use crate::Compiler::AST::{Position, QuickFunction};
use crate::Compiler::Core::DebugMode;
use crate::Compiler::Utilities::SymbolTable;
use crate::Compiler::Utilities::symbol_table::ImportedNamespace;
use crate::ErrorManager::{DebugConfig, ErrorManager};

use super::execution_context::ExecutionContext;

const ABSOLUTE_MAX_RECURSION: u32 = 10_000;
const BASE_RECURSION_DEPTH: u32 = 1_000;

fn calculate_recursion_limit(param_count: usize, body_size: usize) -> u32 {
    let complexity_factor = (param_count * 10 + body_size / 5) as u32;
    (BASE_RECURSION_DEPTH + complexity_factor).min(ABSOLUTE_MAX_RECURSION)
}

/// The execution context a call of `function` starts with, sized for its parameters and the
/// statements of its body (a body declares at most one variable per statement).
fn scope_for(name: &str, function: &DocQuickFunction) -> ExecutionContext {
    ExecutionContext::with_capacity(name, None, function.parameters.len() + function.body.len())
}

/// The key of a namespace in the interpreter's table of imported functions: its address.
fn namespace_key(namespace: &ImportedNamespace) -> usize {
    namespace as *const ImportedNamespace as usize
}

/// The key of a lambda held in `val`, if `val` is a string that starts with `__lam_`.
///
/// Numbers, booleans and null can never print that way, so they are skipped without building
/// their text.
fn lambda_key(val: &DixValue) -> Option<String> {
    if matches!(
        val.get_type(),
        DixType::Int | DixType::Long | DixType::Float | DixType::Double | DixType::Bool | DixType::Null
    ) {
        return None;
    }
    let text = val.as_string();
    text.starts_with("__lam_").then_some(text)
}

/// A date literal as a value.
fn date_value(text: &str) -> Result<DixValue, InterpreterError> {
    use chrono::NaiveDate;
    let date = NaiveDate::parse_from_str(text, "%Y-%m-%d").map_err(|e| {
        InterpreterError::InvalidOperation {
            message: format!("Invalid date format: {}", e),
            position: Position::UNKNOWN,
        }
    })?;
    Ok(DixValue::from_date(chrono::DateTime::from_naive_utc_and_offset(
        date.and_hms_opt(0, 0, 0).unwrap(),
        chrono::Utc,
    )))
}

/// A timestamp literal as a value.
fn timestamp_value(text: &str) -> Result<DixValue, InterpreterError> {
    let timestamp = text
        .parse::<chrono::DateTime<chrono::Utc>>()
        .map_err(|e| InterpreterError::InvalidOperation {
            message: format!("Invalid timestamp format: {}", e),
            position: Position::UNKNOWN,
        })?;
    Ok(DixValue::from_timestamp(timestamp))
}

/// What a parameter holds when `dix` is passed as an argument.
///
/// An argument used to be turned into a literal syntax node and evaluated again in the callee.
/// That conversion is not the identity for every type: a blob and a regex are rebuilt from their
/// text and can fail, a date and a timestamp are parsed again, a tuple is cut to six items or
/// turned into an array depending on `wrap`, and an object is rebuilt in a new map. This does the
/// same conversion directly, without building the intermediate nodes.
fn round_trip(dix: &DixValue, position: Position, wrap: Wrap) -> Result<DixValue, InterpreterError> {
    Ok(match dix.get_type() {
        DixType::Int       => DixValue::from_int(dix.as_int()),
        DixType::Long      => DixValue::from_long(dix.as_long()),
        DixType::Float     => DixValue::from_float(dix.as_float()),
        DixType::Double    => DixValue::from_double(dix.as_double()),
        DixType::String    => DixValue::from_string(dix.as_string()),
        DixType::Bool      => DixValue::from_bool(dix.as_bool()),
        DixType::Null      => DixValue::null(),
        DixType::Hex       => DixValue::from_hex(dix.as_string()),
        DixType::Blob      => DixValue::from_blob(dix.as_blob_base64().unwrap_or_default())
            .map_err(|message| InterpreterError::InvalidOperation { message, position })?,
        DixType::Regex     => DixValue::from_regex(dix.as_string())
            .map_err(|message| InterpreterError::InvalidOperation { message, position })?,
        DixType::Array     => {
            let items = dix.as_array();
            let mut values = Vec::with_capacity(items.len());
            for item in items.iter() {
                values.push(round_trip(item, position, wrap)?);
            }
            DixValue::from_array(values)
        }
        DixType::Tuple     => {
            let items = dix.as_array();
            match wrap {
                Wrap::Body => {
                    let mut values = Vec::with_capacity(items.len());
                    for item in items.iter() {
                        values.push(round_trip(item, position, wrap)?);
                    }
                    DixValue::from_array(values)
                }
                Wrap::Data => {
                    let mut values = Vec::with_capacity(items.len().min(6));
                    for item in items.iter().take(6) {
                        values.push(round_trip(item, position, wrap)?);
                    }
                    DixValue::from_tuple(values)
                }
            }
        }
        DixType::Object    => {
            let object = dix.as_object();
            let mut rebuilt = HashMap::with_capacity(object.len());
            for (key, value) in object.iter() {
                rebuilt.insert(key.clone(), round_trip(value, position, wrap)?);
            }
            DixValue::from_object(rebuilt)
        }
        DixType::Date      => date_value(&dix.as_string())?,
        DixType::Timestamp => timestamp_value(&dix.as_string())?,
        _                  => DixValue::from_string(dix.as_string()),
    })
}

#[derive(Debug, Clone)]
pub enum InterpreterError {
    RecursionLimitExceeded {
        function_name: String,
        position: Position,
        depth: u32,
        limit: u32,
    },
    UndefinedVariable {
        name: String,
        function_name: String,
        position: Position,
        checked_scopes: String,
    },
    UndefinedFunction {
        name: String,
        position: Position,
    },
    NamespaceNotFound {
        name: String,
        position: Position,
    },
    FunctionNotInNamespace {
        namespace: String,
        function: String,
        position: Position,
    },
    ParameterCountMismatch {
        expected: usize,
        got: usize,
        required: usize,
        position: Position,
    },
    ParameterEvalFailed {
        index: usize,
        param_name: String,
        inner: Box<InterpreterError>,
        position: Position,
    },
    DivisionByZero {
        position: Position,
    },
    PropertyNotFound {
        property: String,
        position: Position,
    },
    IndexOutOfBounds {
        index: i64,
        length: usize,
        position: Position,
    },
    InvalidOperation {
        message: String,
        position: Position,
    },
    UnsupportedStatement {
        variant: String,
        position: Position,
    },
    UnsupportedExpression {
        variant: String,
        position: Position,
    },
    BuiltinCallFailed {
        object: String,
        method: String,
        message: String,
        position: Position,
    },
    InvalidEnumAccess {
        location: String,
        position: Position,
    },
    LambdaParamMismatch {
        expected: usize,
        got: usize,
        position: Position,
    },
    ConfigKeyNotFound {
        key: String,
        position: Position,
    },
    ScopeMappingMismatch {
        variable: String,
        mapped_path: String,
        position: Position,
    },
}

impl From<String> for InterpreterError {
    fn from(message: String) -> Self {
        InterpreterError::InvalidOperation {
            message,
            position: Position::UNKNOWN,
        }
    }
}

impl std::fmt::Display for InterpreterError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            InterpreterError::RecursionLimitExceeded {
                function_name,
                position,
                depth,
                limit,
            } => write!(
                f,
                "Recursion limit exceeded in '{}' at {} (depth: {}, limit: {})",
                function_name, position, depth, limit
            ),
            InterpreterError::UndefinedVariable {
                name,
                function_name,
                position,
                checked_scopes,
            } => write!(
                f,
                "Undefined variable '{}' in function '{}' at {} (checked: {})",
                name, function_name, position, checked_scopes
            ),
            InterpreterError::UndefinedFunction { name, position } => {
                write!(f, "Undefined function '{}' at {}", name, position)
            }
            InterpreterError::ParameterCountMismatch {
                expected,
                got,
                required,
                position,
            } => write!(
                f,
                "Parameter count mismatch at {}: expected {}, got {} (required: {})",
                position, expected, got, required
            ),
            InterpreterError::DivisionByZero { position } => {
                write!(f, "Division by zero at {}", position)
            }
            InterpreterError::InvalidOperation { message, position } => {
                write!(f, "Invalid operation at {}: {}", position, message)
            }
            _ => write!(f, "{:?}", self),
        }
    }
}

impl std::error::Error for InterpreterError {}

// ── LambdaAst ─────────────────────────────────────────────────────────────────
/// A lambda definition: handles into the arena the lambda was written in, plus the variables it
/// captured. Creating one copies no syntax tree, because the parameters, the body and the
/// statements are only ids of nodes that already exist.
#[derive(Debug, Clone)]
pub struct LambdaAst {
    pub params:       StrList,
    pub body:         ExprId,
    pub statements:   StmtList,
    /// Variables captured from the enclosing scope at lambda-definition time.
    /// `None` when the lambda was defined in an empty / global context.
    pub captured_env: Option<FxHashMap<String, DixValue>>,
}

/// How the arguments of a call are turned into the values a function's parameters hold.
///
/// Every argument is evaluated in the caller first and then goes through a conversion to a
/// literal and back, which is not the identity for every type. The two call paths used two
/// different conversions, and the difference is observable, so both are kept.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Wrap {
    /// A call found in `@DATA`. A tuple stays a tuple (cut to its first six items).
    Data,
    /// A call made inside a function body. A tuple becomes an array.
    Body,
}

/// The already evaluated arguments of one call, and how to convert them (see [`Wrap`]).
#[derive(Debug, Clone, Copy)]
pub struct CallArgs<'x> {
    /// The arguments, evaluated in the caller's context.
    pub values: &'x [DixValue],
    /// Which conversion the arguments go through before they are bound.
    pub wrap: Wrap,
    /// The position of the call; conversion errors carry it.
    pub position: Position,
}

/// The object a method is called on: an expression, or a bare name that is read as a variable.
#[derive(Clone, Copy)]
enum InstanceSource<'x> {
    Expr(ExprId),
    Identifier(&'x str, Position),
}

/// Executes the functions of `@QUICKFUNCS` and of imported namespaces over the arena AST.
///
/// Create one with [`new_with_error_manager`](Self::new_with_error_manager), copy the functions it
/// can call into the arena with [`register_functions`](Self::register_functions), then run calls
/// with [`execute_data_call`](Self::execute_data_call).
pub struct FunctionInterpreter<'a> {
    symbol_table:             &'a SymbolTable,
    /// The functions of `@QUICKFUNCS`, by name; when a name is defined twice the first wins.
    quick_functions:          FxHashMap<String, Rc<DocQuickFunction>>,
    /// The functions of each imported namespace, keyed by the address of the namespace in the
    /// symbol table. The table is borrowed for `'a` and never changed while the interpreter
    /// lives, so an address names exactly one namespace.
    imported_functions:       FxHashMap<usize, FxHashMap<String, Rc<DocQuickFunction>>>,
    data_context:             Rc<RefCell<FxHashMap<String, DixValue>>>,
    debug_config:             DebugConfig,
    recursion_depth:          u32,
    current_recursion_limit:  u32,
    /// The lambdas defined so far, by reference key. Entries are shared (`Rc`) because every
    /// invocation and every `let g = f` takes a copy of the entry. An entry is never changed
    /// after it is inserted.
    lambda_registry:          FxHashMap<String, Rc<LambdaAst>>,
    /// Monotonically-increasing counter used to generate unique lambda reference
    /// keys of the form `"__lam_N"`.  These keys are stored as DixValue strings
    /// and allow lambdas to be passed as first-class values.
    lambda_counter:           u64,
    log_statements:           Vec<String>,
    error_manager:            ErrorManager,
}

impl<'a> FunctionInterpreter<'a> {
    pub fn new(
        symbol_table: &'a SymbolTable,
        data_context: Rc<RefCell<FxHashMap<String, DixValue>>>,
        debug_mode: DebugMode,
    ) -> Self {
        let error_manager = ErrorManager::get_shared_instance();
        Self::new_with_error_manager(symbol_table, data_context, debug_mode, error_manager)
    }

    pub fn new_with_error_manager(
        symbol_table:  &'a SymbolTable,
        data_context:  Rc<RefCell<FxHashMap<String, DixValue>>>,
        debug_mode:    DebugMode,
        error_manager: ErrorManager,
    ) -> Self {
        FunctionInterpreter {
            symbol_table,
            quick_functions: FxHashMap::default(),
            imported_functions: FxHashMap::default(),
            data_context,
            debug_config: DebugConfig::from_debug_mode(debug_mode),
            recursion_depth: 0,
            current_recursion_limit: BASE_RECURSION_DEPTH,
            lambda_registry: FxHashMap::with_capacity_and_hasher(4, Default::default()),
            lambda_counter: 0,
            log_statements: Vec::with_capacity(4),
            error_manager,
        }
    }

    /// Copies the functions the interpreter can call into `arena`: the `local` functions of
    /// `@QUICKFUNCS` and every function of every imported namespace.
    ///
    /// The interpreter reads function bodies from the arena it is handed, so this has to run
    /// once, before the first call. Copying costs the size of the function bodies once, where
    /// the interpreter used to copy a function's whole tree for every call.
    pub fn register_functions(&mut self, arena: &mut Arena, local: &[QuickFunction]) {
        for function in local {
            if !self.quick_functions.contains_key(&function.name) {
                let copy = Rc::new(DocQuickFunction::from_owned(arena, function));
                self.quick_functions.insert(function.name.clone(), copy);
            }
        }
        self.register_imported_functions(arena);
    }

    /// Like [`register_functions`](Self::register_functions) for local functions that already
    /// live in `arena`, the document's own enhanced `@QUICKFUNCS` section: they are registered
    /// as they are and nothing is copied for them, which saves the copy the owned form pays. The
    /// first function of a name wins, as there.
    pub fn register_document_functions(&mut self, arena: &mut Arena, local: &[DocQuickFunction]) {
        for function in local {
            if !self.quick_functions.contains_key(&function.name) {
                self.quick_functions.insert(function.name.clone(), Rc::new(function.clone()));
            }
        }
        self.register_imported_functions(arena);
    }

    /// Copies every function of every imported namespace into `arena`, once per namespace.
    fn register_imported_functions(&mut self, arena: &mut Arena) {
        for namespace in self.symbol_table.namespaces.values() {
            if namespace.functions.is_empty() {
                continue;
            }
            let mut table = FxHashMap::with_capacity_and_hasher(
                namespace.functions.len(),
                Default::default(),
            );
            for (name, info) in &namespace.functions {
                table.insert(name.clone(), Rc::new(DocQuickFunction::from_owned(arena, &info.ast)));
            }
            self.imported_functions.insert(namespace_key(namespace), table);
        }
    }

    pub fn update_data_context(&mut self, key: String, value: DixValue) {
        if self.debug_config.is_enabled {
            self.error_manager.log_debug(&format!(
                "Updated data context: {} = {}",
                key,
                value.get_type().get_type_name()
            ));
        }
        self.data_context.borrow_mut().insert(key, value);
    }

    /// The function of `@QUICKFUNCS` with this name.
    pub fn find_function(&self, name: &str) -> Option<&DocQuickFunction> {
        self.quick_functions.get(name).map(|function| &**function)
    }

    pub fn take_logs(&mut self) -> Vec<String> {
        std::mem::take(&mut self.log_statements)
    }

    /// Runs `function` with `arguments` bound to its parameters.
    pub fn execute(
        &mut self,
        arena: &Arena,
        function: &DocQuickFunction,
        arguments: CallArgs<'_>,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let param_count = function.parameters.len();
        let body_size = function.body.len();
        self.current_recursion_limit = calculate_recursion_limit(param_count, body_size);

        self.recursion_depth += 1;

        if self.recursion_depth > self.current_recursion_limit {
            let err = InterpreterError::RecursionLimitExceeded {
                function_name: function.name.clone(),
                position: function.position,
                depth: self.recursion_depth,
                limit: self.current_recursion_limit,
            };
            self.recursion_depth -= 1;
            self.error_manager.add_value_resolution_error(
                crate::ErrorManager::ValueResolutionErrorType::InvalidOperation,
                format!("Recursion limit exceeded in '{}'", function.name),
                function.position.line as i32,
                function.position.column as i32,
                Some("@QUICKFUNCS".to_string()),
                None,
                Some(function.name.clone()),
                Some("Check for infinite recursion".to_string()),
            );
            return Err(err);
        }

        self.bind_parameters(
            arena,
            &function.parameters,
            arguments,
            context,
            scope_context,
            namespace,
        )?;

        let mut last_result = DixValue::null();

        for (i, &statement) in arena.stmt_list(function.body).iter().enumerate() {
            if self.debug_config.is_enabled {
                self.error_manager.log_debug(&format!(
                    "[Execute] Statement {}/{}: {}",
                    i + 1,
                    function.body.len(),
                    statement_variant_name(arena.stmt(statement))
                ));
            }

            last_result =
                self.execute_statement(arena, statement, context, scope_context, namespace)?;

            if matches!(arena.stmt(statement), StmtNode::Return { .. }) {
                if self.debug_config.is_enabled {
                    self.error_manager.log_debug(&format!(
                        "[Execute] Explicit return: {}",
                        last_result.get_type().get_type_name()
                    ));
                }
                self.recursion_depth -= 1;
                return Ok(last_result);
            }
        }

        if self.debug_config.is_enabled {
            self.error_manager.log_debug(&format!(
                "[Execute] Implicit return: {}",
                last_result.get_type().get_type_name()
            ));
        }

        self.recursion_depth -= 1;
        Ok(last_result)
    }

    fn bind_parameters(
        &mut self,
        arena: &Arena,
        parameters: &[DocQuickFuncParam],
        arguments: CallArgs<'_>,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<(), InterpreterError> {
        let required_count = parameters
            .iter()
            .filter(|p| p.default_value.is_none())
            .count();
        let given = arguments.values.len();

        if given < required_count {
            let position = parameters
                .first()
                .map(|p| p.position)
                .unwrap_or(Position::UNKNOWN);
            return Err(InterpreterError::ParameterCountMismatch {
                expected: parameters.len(),
                got: given,
                required: required_count,
                position,
            });
        }

        for (i, param) in parameters.iter().enumerate() {
            let value = if i < given {
                round_trip(&arguments.values[i], arguments.position, arguments.wrap)
                    .map_err(|e| InterpreterError::ParameterEvalFailed {
                        index: i,
                        param_name: param.name.clone(),
                        inner: Box::new(e),
                        position: arguments.position,
                    })?
            } else if let Some(default) = param.default_value {
                self.evaluate_expression(arena, default, context, scope_context, namespace)
                    .map_err(|e| InterpreterError::ParameterEvalFailed {
                        index: i,
                        param_name: param.name.clone(),
                        inner: Box::new(e),
                        position: param.position,
                    })?
            } else {
                return Err(InterpreterError::ParameterCountMismatch {
                    expected: parameters.len(),
                    got: given,
                    required: required_count,
                    position: param.position,
                });
            };

            context
                .define_variable(&param.name, value)
                .map_err(|e| InterpreterError::InvalidOperation {
                    message: e.to_string(),
                    position: param.position,
                })?;
        }

        Ok(())
    }

    fn resolve_identifier(
        &self,
        name: &str,
        position: Position,
        context: &ExecutionContext,
        scope_context: &FxHashMap<String, String>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_enabled {
            self.error_manager
                .log_debug(&format!("[ResolveId] Resolving: {}", name));
        }

        if let Ok(value) = context.get_variable(name) {
            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "  Found in execution context: {}",
                    value.get_type().get_type_name()
                ));
            }
            return Ok(value);
        }

        if let Some(full_path) = scope_context.get(name) {
            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "  Checking scope context: {} -> {}",
                    name, full_path
                ));
            }
            if let Some(value) = self.data_context.borrow().get(full_path) {
                if self.debug_config.is_verbose {
                    self.error_manager.log_debug(&format!(
                        "  Found in scope context: {}",
                        value.get_type().get_type_name()
                    ));
                }
                return Ok(value.clone());
            } else {
                return Err(InterpreterError::ScopeMappingMismatch {
                    variable: name.to_string(),
                    mapped_path: full_path.clone(),
                    position,
                });
            }
        }

        if let Some(value) = self.try_resolve_by_path_suffix(name) {
            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "  Found by path search: {}",
                    value.get_type().get_type_name()
                ));
            }
            return Ok(value);
        }

        if let Some(value) = self.data_context.borrow().get(name) {
            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "  Found in global context: {}",
                    value.get_type().get_type_name()
                ));
            }
            return Ok(value.clone());
        }

        let scope_keys = scope_context
            .keys()
            .map(|s| s.as_str())
            .collect::<Vec<_>>()
            .join(", ");

        Err(InterpreterError::UndefinedVariable {
            name: name.to_string(),
            function_name: context.function_name().to_string(),
            position,
            checked_scopes: scope_keys,
        })
    }

    fn try_resolve_by_path_suffix(&self, name: &str) -> Option<DixValue> {
        let suffix = format!(".{}", name);
        let data_ctx = self.data_context.borrow();
        for (key, value) in data_ctx.iter() {
            if *key == name || key.ends_with(&suffix) {
                return Some(value.clone());
            }
        }
        None
    }

    fn execute_statement(
        &mut self,
        arena: &Arena,
        statement: StmtId,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let node = *arena.stmt(statement);
        if self.debug_config.is_verbose {
            self.error_manager.log_debug(&format!(
                "[ExecuteStatement] {}",
                statement_variant_name(&node)
            ));
        }

        match node {
            StmtNode::Return { value, .. } => {
                self.execute_return(arena, value, context, scope_context, namespace)
            }
            StmtNode::Assignment { variable, value, position } => self.execute_assignment(
                arena, arena.text(variable), value, position, context, scope_context, namespace,
            ),
            StmtNode::ArithmeticAssignment { variable, operator, value, position } => {
                self.execute_arithmetic_assignment(
                    arena,
                    arena.text(variable),
                    arena.text(operator),
                    value,
                    position,
                    context,
                    scope_context,
                    namespace,
                )
            }
            StmtNode::If { condition, then_branch, else_branch, position } => self.execute_if(
                arena,
                condition,
                then_branch,
                else_branch,
                position,
                context,
                scope_context,
                namespace,
            ),
            StmtNode::Switch { expression, cases, default_case, position } => self.execute_switch(
                arena,
                expression,
                cases,
                default_case,
                position,
                context,
                scope_context,
                namespace,
            ),
            StmtNode::Log { value, position } => {
                self.execute_log(arena, value, position, context, scope_context, namespace)
            }
            StmtNode::VariableDeclaration { variable_name, value, position, .. } => {
                self.execute_variable_declaration(
                    arena,
                    arena.text(variable_name),
                    value,
                    position,
                    context,
                    scope_context,
                    namespace,
                )
            }
            StmtNode::ExpressionStatement { expression, .. } => {
                self.evaluate_expression(arena, expression, context, scope_context, namespace)
            }
            StmtNode::ObjectCreation { variable, object, position } => self.execute_object_creation(
                arena, arena.text(variable), object, position, context, scope_context, namespace,
            ),
        }
    }

    fn execute_return(
        &mut self,
        arena: &Arena,
        value: ExprId,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_enabled {
            self.error_manager
                .log_debug("[ExecuteReturn] Processing return statement");
        }

        let return_value =
            self.evaluate_expression(arena, value, context, scope_context, namespace)?;

        if self.debug_config.is_enabled {
            self.error_manager.log_debug(&format!(
                "[ExecuteReturn] Evaluated to: {} = {}",
                return_value.get_type().get_type_name(),
                return_value
            ));
        }

        Ok(return_value)
    }

    fn execute_assignment(
        &mut self,
        arena: &Arena,
        variable:      &str,
        value:         ExprId,
        position:      Position,
        context:       &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace:     Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let val = self.evaluate_expression(arena, value, context, scope_context, namespace)?;

        // Keep the lambda registry entry for this variable name in sync whenever a
        // variable is reassigned to a different lambda (e.g. after a re-assignment
        // inside a loop or after receiving a lambda from a higher-order function).
        if let Some(val_str) = lambda_key(&val) {
            if let Some(lambda) = self.lambda_registry.get(&val_str).cloned() {
                if self.debug_config.is_enabled {
                    self.error_manager.log_debug(&format!(
                        "[Lambda] Updated registry for '{}' via key {}",
                        variable, val_str
                    ));
                }
                self.lambda_registry.insert(variable.to_string(), lambda);
            }
        }

        if context.has_variable(variable) {
            context
                .set_variable(variable, val.clone())
                .map_err(|e| InterpreterError::InvalidOperation {
                    message:  e.to_string(),
                    position,
                })?;
        } else {
            context
                .define_variable(variable, val.clone())
                .map_err(|e| InterpreterError::InvalidOperation {
                    message:  e.to_string(),
                    position,
                })?;
        }

        Ok(val)
    }

    fn execute_variable_declaration(
        &mut self,
        arena: &Arena,
        variable_name: &str,
        value:         ExprId,
        position:      Position,
        context:       &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace:     Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_enabled {
            self.error_manager.log_debug(&format!(
                "[ExecuteVariableDeclaration] {}",
                variable_name
            ));
        }

        let val = self.evaluate_expression(arena, value, context, scope_context, namespace)?;

        // If the result is a lambda reference key ("__lam_N"), also register the
        // LambdaAst under the variable name so that direct calls like
        // `variable_name(args)` resolve via the lambda registry name lookup.
        // This handles both literal lambda assignments AND lambdas returned from
        // higher-order functions (e.g. `let addFive = outer(5)`).
        if let Some(val_str) = lambda_key(&val) {
            if let Some(lambda) = self.lambda_registry.get(&val_str).cloned() {
                if self.debug_config.is_enabled {
                    self.error_manager.log_debug(&format!(
                        "[Lambda] Registered '{}' via key {}",
                        variable_name, val_str
                    ));
                }
                self.lambda_registry.insert(variable_name.to_string(), lambda);
            }
        }

        context
            .define_variable(variable_name, val.clone())
            .map_err(|e| InterpreterError::InvalidOperation {
                message:  e.to_string(),
                position,
            })?;

        Ok(val)
    }

    fn execute_arithmetic_assignment(
        &mut self,
        arena: &Arena,
        variable: &str,
        operator: &str,
        value: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let current_value =
            context.get_variable(variable).map_err(|_| {
                InterpreterError::UndefinedVariable {
                    name: variable.to_string(),
                    function_name: context.function_name().to_string(),
                    position,
                    checked_scopes: "execution context".to_string(),
                }
            })?;

        let operand_value =
            self.evaluate_expression(arena, value, context, scope_context, namespace)?;

        let use_long = current_value.get_type() == DixType::Long
            || operand_value.get_type() == DixType::Long;

        let result = match operator {
            "+=" => current_value.add(&operand_value).map_err(|e| {
                InterpreterError::InvalidOperation { message: e, position }
            })?,
            "-=" => current_value
                .subtract(&operand_value)
                .map_err(|e| InterpreterError::InvalidOperation { message: e, position })?,
            "*=" => current_value
                .multiply(&operand_value)
                .map_err(|e| InterpreterError::InvalidOperation { message: e, position })?,
            "/=" => current_value.divide(&operand_value).map_err(|e| {
                if e.contains("zero") {
                    InterpreterError::DivisionByZero { position }
                } else {
                    InterpreterError::InvalidOperation { message: e, position }
                }
            })?,
            // Modulo: preserve Long when both operands are integer types
            "%=" => {
                if use_long && current_value.get_type() != DixType::Float
                    && current_value.get_type() != DixType::Double
                    && operand_value.get_type() != DixType::Float
                    && operand_value.get_type() != DixType::Double
                {
                    let rv = operand_value.as_long();
                    if rv == 0 {
                        return Err(InterpreterError::DivisionByZero { position });
                    }
                    DixValue::from_long(current_value.as_long() % rv)
                } else {
                    DixValue::from_double(
                        current_value.as_double() % operand_value.as_double(),
                    )
                }
            }
            "**=" => DixValue::from_double(
                current_value
                    .as_double()
                    .powf(operand_value.as_double()),
            ),
            // Bitwise assign ops - use Long path if either operand is Long
            "&=" => {
                if use_long {
                    DixValue::from_long(current_value.as_long() & operand_value.as_long())
                } else {
                    DixValue::from_int(current_value.as_int() & operand_value.as_int())
                }
            }
            "|=" => {
                if use_long {
                    DixValue::from_long(current_value.as_long() | operand_value.as_long())
                } else {
                    DixValue::from_int(current_value.as_int() | operand_value.as_int())
                }
            }
            "^=" => {
                if use_long {
                    DixValue::from_long(current_value.as_long() ^ operand_value.as_long())
                } else {
                    DixValue::from_int(current_value.as_int() ^ operand_value.as_int())
                }
            }
            "<<=" => {
                if use_long {
                    DixValue::from_long(current_value.as_long() << operand_value.as_long())
                } else {
                    DixValue::from_int(current_value.as_int() << operand_value.as_int())
                }
            }
            ">>=" => {
                if use_long {
                    DixValue::from_long(current_value.as_long() >> operand_value.as_long())
                } else {
                    DixValue::from_int(current_value.as_int() >> operand_value.as_int())
                }
            }
            _ => {
                return Err(InterpreterError::UnsupportedStatement {
                    variant: format!("Arithmetic assignment operator: {}", operator),
                    position,
                })
            }
        };

        context
            .set_variable(variable, result.clone())
            .map_err(|e| InterpreterError::InvalidOperation {
                message: e.to_string(),
                position,
            })?;

        Ok(result)
    }

    fn execute_object_creation(
        &mut self,
        arena: &Arena,
        variable: &str,
        object: ValueId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let dix_obj = self.convert_ast_value_to_dix_value(arena, 
            object,
            context,
            scope_context,
            namespace,
        )?;

        context
            .define_variable(variable, dix_obj.clone())
            .map_err(|e| InterpreterError::InvalidOperation {
                message: e.to_string(),
                position,
            })?;

        Ok(dix_obj)
    }

    fn execute_if(
        &mut self,
        arena: &Arena,
        condition: ExprId,
        then_branch: StmtList,
        else_branch: Option<StmtList>,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_enabled {
            self.error_manager
                .log_debug("[ExecuteIf] Evaluating condition");
        }

        let cond_value =
            self.evaluate_expression(arena, condition, context, scope_context, namespace)?;

        if self.debug_config.is_verbose {
            self.error_manager.log_debug(&format!(
                "[ExecuteIf] Condition: {}",
                cond_value.as_bool()
            ));
        }

        if cond_value.as_bool() {
            if self.debug_config.is_enabled {
                self.error_manager
                    .log_debug("[ExecuteIf] Taking THEN branch");
            }
            let mut last_result = DixValue::null();
            for &stmt in arena.stmt_list(then_branch) {
                last_result = self.execute_statement(arena, 
                    stmt, context, scope_context, namespace,
                )?;
                if matches!(arena.stmt(stmt), StmtNode::Return { .. }) {
                    if self.debug_config.is_enabled {
                        self.error_manager.log_debug(&format!(
                            "[ExecuteIf] Explicit return from THEN: {}",
                            last_result
                        ));
                    }
                    return Ok(last_result);
                }
            }
            Ok(last_result)
        } else if let Some(else_stmts) = else_branch {
            if self.debug_config.is_enabled {
                self.error_manager
                    .log_debug("[ExecuteIf] Taking ELSE branch");
            }
            let mut last_result = DixValue::null();
            for &stmt in arena.stmt_list(else_stmts) {
                last_result = self.execute_statement(arena, 
                    stmt, context, scope_context, namespace,
                )?;
                if matches!(arena.stmt(stmt), StmtNode::Return { .. }) {
                    if self.debug_config.is_enabled {
                        self.error_manager.log_debug(&format!(
                            "[ExecuteIf] Explicit return from ELSE: {}",
                            last_result
                        ));
                    }
                    return Ok(last_result);
                }
            }
            Ok(last_result)
        } else {
            if self.debug_config.is_enabled {
                self.error_manager
                    .log_debug("[ExecuteIf] No branch taken");
            }
            Ok(DixValue::null())
        }
    }

    fn execute_switch(
        &mut self,
        arena: &Arena,
        expression: ExprId,
        cases: CaseList,
        default_case: Option<CaseId>,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_enabled {
            self.error_manager
                .log_debug("[ExecuteSwitch] Evaluating switch expression");
        }

        let switch_value =
            self.evaluate_expression(arena, expression, context, scope_context, namespace)?;

        if self.debug_config.is_verbose {
            self.error_manager.log_debug(&format!(
                "[ExecuteSwitch] Switch value: {} = {}",
                switch_value.get_type().get_type_name(),
                switch_value
            ));
        }

        for (i, case) in arena.case_list(cases).iter().enumerate() {
            let case_value = self.convert_ast_value_to_dix_value(
                arena,
                case.case_value,
                context,
                scope_context,
                namespace,
            )?;

            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "[ExecuteSwitch] Comparing with case [{}]: {}",
                    i, case_value
                ));
            }

            if switch_value.equal_to(&case_value) {
                if self.debug_config.is_enabled {
                    self.error_manager.log_debug(&format!(
                        "[ExecuteSwitch] Match found at case [{}]",
                        i
                    ));
                }
                let mut last_result = DixValue::null();
                for &stmt in arena.stmt_list(case.statements) {
                    last_result = self.execute_statement(arena, 
                        stmt, context, scope_context, namespace,
                    )?;
                    if matches!(arena.stmt(stmt), StmtNode::Return { .. }) {
                        return Ok(last_result);
                    }
                }
                return Ok(last_result);
            }
        }

        if let Some(default) = default_case.map(|id| arena.case(id)) {
            if self.debug_config.is_enabled {
                self.error_manager
                    .log_debug("[ExecuteSwitch] No match, executing default");
            }
            let mut last_result = DixValue::null();
            for &stmt in arena.stmt_list(default.statements) {
                last_result = self.execute_statement(arena, 
                    stmt, context, scope_context, namespace,
                )?;
                if matches!(arena.stmt(stmt), StmtNode::Return { .. }) {
                    return Ok(last_result);
                }
            }
            return Ok(last_result);
        }

        if self.debug_config.is_enabled {
            self.error_manager
                .log_debug("[ExecuteSwitch] No match and no default");
        }

        Ok(DixValue::null())
    }

    fn execute_log(
        &mut self,
        arena: &Arena,
        value: ExprId,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let val =
            self.evaluate_expression(arena, value, context, scope_context, namespace)?;
        let message = val.as_string();

        self.log_statements.push(message.clone());

        if self.debug_config.is_enabled {
            self.error_manager
                .log_debug(&format!("[log:] {}", message));
        }

        Ok(DixValue::null())
    }
    fn evaluate_expression(
        &mut self,
        arena: &Arena,
        expr: ExprId,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let node = *arena.expr(expr);
        match node {
            ExprNode::Identifier { name, position } => {
                self.resolve_identifier(arena.text(name), position, context, scope_context)
            }

            ExprNode::Value { value, .. } => {
                self.convert_ast_value_to_dix_value(arena, value, context, scope_context, namespace)
            }

            ExprNode::ArithmeticOp { left, operator, right, position } => {
                self.evaluate_arithmetic_op(
                    arena, left, arena.text(operator), right, position, context, scope_context, namespace,
                )
            }

            ExprNode::BitwiseOp { left, operator, right, position } => {
                self.evaluate_bitwise_op(
                    arena, left, arena.text(operator), right, position, context, scope_context, namespace,
                )
            }

            ExprNode::ComparisonOp { left, operator, right, position } => {
                self.evaluate_comparison_op(
                    arena, left, arena.text(operator), right, position, context, scope_context, namespace,
                )
            }

            ExprNode::LogicalOp { left, operator, right, position } => {
                self.evaluate_logical_op(
                    arena, left, arena.text(operator), right, position, context, scope_context, namespace,
                )
            }

            ExprNode::UnaryOp { operator, operand, position } => {
                self.evaluate_unary_op(
                    arena, arena.text(operator), operand, position, context, scope_context, namespace,
                )
            }

            ExprNode::Conditional { condition, true_value, false_value, position } => {
                self.evaluate_conditional(
                    arena, condition, true_value, false_value, position, context, scope_context, namespace,
                )
            }

            ExprNode::StaticMethodCall { object_name, method_name, arguments, position } => {
                self.evaluate_static_method_call(
                    arena,
                    arena.text(object_name),
                    arena.text(method_name),
                    arguments,
                    position,
                    context,
                    scope_context,
                    namespace,
                )
            }

            ExprNode::InstanceMethodCall { instance, method_name, arguments, position } => {
                self.evaluate_instance_method_call(
                    arena,
                    InstanceSource::Expr(instance),
                    arena.text(method_name),
                    arguments,
                    position,
                    context,
                    scope_context,
                    namespace,
                )
            }

            ExprNode::PropertyAccess { object, property, position } => {
                self.evaluate_property_access(
                    arena, object, arena.text(property), position, context, scope_context, namespace,
                )
            }

            ExprNode::IndexAccess { object, index, position } => {
                self.evaluate_index_access(
                    arena, object, index, position, context, scope_context, namespace,
                )
            }

            ExprNode::EnumAccess { namespace_name, enum_name, value, position } => {
                self.evaluate_enum_access(
                    namespace_name.map(|n| arena.text(n)),
                    arena.text(enum_name),
                    arena.text(value),
                    position,
                    namespace,
                )
            }

            ExprNode::QuickFuncCall { name, arguments, position } => {
                self.evaluate_quick_func_call(
                    arena, arena.text(name), arguments, position, context, scope_context, namespace,
                )
            }

            ExprNode::ImportedFunctionCall { namespace_name, function_name, arguments, position } => {
                self.evaluate_imported_function_call(
                    arena,
                    arena.text(namespace_name),
                    arena.text(function_name),
                    arguments,
                    position,
                    context,
                    scope_context,
                )
            }

            ExprNode::ConfigAccess { key, position } => {
                self.evaluate_config_access(arena.text(key), position)
            }

            ExprNode::Parenthesized { expression, .. } => {
                self.evaluate_expression(arena, expression, context, scope_context, namespace)
            }

            // ── CRITICAL FIX: runtime fallback for QualifiedIdentifiers that  ──
            // ── were not resolved by the AST enhancement phase.               ──
            // ── This should be rare - the enhancer handles the common cases.  ──
            ExprNode::QualifiedIdentifier { parts, arguments, position } => {
                let parts = arena.str_list(parts);
                if parts.is_empty() {
                    return Ok(DixValue::null());
                }

                if let Some(args) = arguments {
                    // ── Call form: a.b(args) or StaticObj.method(args) ────────────
                    if parts.len() == 2 {
                        let first  = arena.text(parts[0]);
                        let second = arena.text(parts[1]);

                        // Static builtin: uppercase first letter → Math.sqrt(), DateTime.now()
                        if builtin_call_resolver::has_static_object(first) {
                            let mut arg_vals = Vec::with_capacity(args.len());
                            for &a in arena.expr_list(args) {
                                arg_vals.push(self.evaluate_expression(
                                    arena, a, context, scope_context, namespace,
                                )?);
                            }
                            return builtin_call_resolver::resolve_static_call(
                                first, second, &arg_vals,
                            )
                            .map_err(|e| InterpreterError::BuiltinCallFailed {
                                object:   first.to_string(),
                                method:   second.to_string(),
                                message:  e,
                                position,
                            });
                        }

                        // Instance method on a local variable - routes through
                        // evaluate_instance_method_call which has the lambda fixes.
                        return self.evaluate_instance_method_call(
                            arena,
                            InstanceSource::Identifier(first, position),
                            second,
                            args,
                            position,
                            context,
                            scope_context,
                            namespace,
                        );
                    }

                    if parts.len() > 2 {
                        // Chained: a.b.c(args) - walk the property chain, then call .c(args).
                        let method_name   = arena.text(parts[parts.len() - 1]);
                        let instance_segs = &parts[..parts.len() - 1];

                        let mut val = self.resolve_identifier(
                            arena.text(instance_segs[0]), position, context, scope_context,
                        )?;
                        for &seg in &instance_segs[1..] {
                            let seg = arena.text(seg);
                            if val.get_type() == DixType::Object {
                                val = val
                                    .as_object()
                                    .get(seg)
                                    .cloned()
                                    .ok_or_else(|| InterpreterError::PropertyNotFound {
                                        property: seg.to_string(),
                                        position,
                                    })?;
                            } else {
                                return Err(InterpreterError::InvalidOperation {
                                    message: format!(
                                        "Cannot access '{}' on {:?}",
                                        seg,
                                        val.get_type()
                                    ),
                                    position,
                                });
                            }
                        }

                        // ── Fix: lambda ref in property chain ─────────────────────────
                        // If the chain resolves to a lambda ref string, invoke it BEFORE
                        // evaluating arg_vals.  Evaluating args first then dispatching to
                        // resolve_instance_call would hit the same String/call failure.
                        // Also handles Object property lambdas via Fix B above.
                        if val.get_type() == DixType::String {
                            if let Some(val_str) = lambda_key(&val) {
                                if let Some(lambda) = self.lambda_registry.get(&val_str).cloned() {
                                    if self.debug_config.is_enabled {
                                        self.error_manager.log_debug(&format!(
                                            "[QualifiedIdentifier chain] Lambda ref '{}' invoked via {}()",
                                            val_str, method_name
                                        ));
                                    }
                                    return self.invoke_lambda(
                                        arena, &lambda, args, position, context, scope_context, namespace,
                                    );
                                }
                            }
                        }

                        let mut arg_vals = Vec::with_capacity(args.len());
                        for &a in arena.expr_list(args) {
                            arg_vals.push(self.evaluate_expression(
                                arena, a, context, scope_context, namespace,
                            )?);
                        }

                        return builtin_call_resolver::resolve_instance_call(
                            &val, method_name, &arg_vals,
                        )
                        .map_err(|e| InterpreterError::BuiltinCallFailed {
                            object:   format!("{:?}", val.get_type()),
                            method:   method_name.to_string(),
                            message:  e,
                            position,
                        });
                    }

                    // Single part with args - treat as QuickFuncCall.
                    return self.evaluate_quick_func_call(
                        arena, arena.text(parts[0]), args, position, context, scope_context, namespace,
                    );
                }

                // ── Property-access form: a.b.c (no call) ────────────────────────────
                let mut result = self.resolve_identifier(
                    arena.text(parts[0]), position, context, scope_context,
                )?;
                for &part in &parts[1..] {
                    let part = arena.text(part);
                    match result.get_type() {
                        DixType::Object => {
                            result = result
                                .as_object()
                                .get(part)
                                .cloned()
                                .ok_or_else(|| InterpreterError::PropertyNotFound {
                                    property: part.to_string(),
                                    position,
                                })?;
                        }
                        _ => {
                            return Err(InterpreterError::InvalidOperation {
                                message: format!(
                                    "Cannot access property '{}' on {:?}",
                                    part,
                                    result.get_type()
                                ),
                                position,
                            });
                        }
                    }
                }
                Ok(result)
            }

            other => Err(InterpreterError::UnsupportedExpression {
                variant:  expr_variant_name(&other).to_string(),
                position: other.position(),
            }),
        }
    }

    fn evaluate_arithmetic_op(
        &mut self,
        arena: &Arena,
        left: ExprId,
        operator: &str,
        right: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if matches!(operator, "<<" | ">>" | "&" | "|" | "^") {
            return self.evaluate_bitwise_op(arena, 
                left, operator, right, position, context, scope_context, namespace,
            );
        }

        match operator {
            "%%" => {
                return self.evaluate_circular_modulo(arena, 
                    left, right, position, context, scope_context, namespace,
                )
            }
            "%&" => {
                return self.evaluate_percentage(arena, 
                    left, right, position, context, scope_context, namespace,
                )
            }
            "&%" => {
                return self.evaluate_bitwise_modulo(arena, 
                    left, right, position, context, scope_context, namespace,
                )
            }
            _ => {}
        }

        let left_val  = self.evaluate_expression(arena, left,  context, scope_context, namespace)?;
        let right_val = self.evaluate_expression(arena, right, context, scope_context, namespace)?;

        let left_type  = left_val.get_type();
        let right_type = right_val.get_type();

        // Long-integer arithmetic path: preserves i64 precision when neither
        // operand is Float or Double, and at least one is Long.
        let use_long = matches!((left_type, right_type),
        (DixType::Long, DixType::Long)
        | (DixType::Long, DixType::Int)
        | (DixType::Int,  DixType::Long)
    );

        if use_long {
            let lv = left_val.as_long();
            let rv = right_val.as_long();
            let result: Result<DixValue, String> = match operator {
                "+" => Ok(DixValue::from_long(lv.wrapping_add(rv))),
                "-" => Ok(DixValue::from_long(lv.wrapping_sub(rv))),
                "*" => Ok(DixValue::from_long(lv.wrapping_mul(rv))),
                "/" => {
                    if rv == 0 {
                        Err("division by zero".to_string())
                    } else {
                        Ok(DixValue::from_long(lv / rv))
                    }
                }
                "%" => {
                    if rv == 0 {
                        Err("division by zero".to_string())
                    } else {
                        Ok(DixValue::from_long(lv % rv))
                    }
                }
                // Power always returns Double for Long (same as standard numeric semantics)
                "**" => Ok(DixValue::from_double((lv as f64).powf(rv as f64))),
                _ => Err(format!("Unknown arithmetic operator: {}", operator)),
            };
            return result.map_err(|e| {
                if e.contains("zero") {
                    InterpreterError::DivisionByZero { position }
                } else {
                    InterpreterError::InvalidOperation { message: e, position }
                }
            });
        }

        // Standard float/double/int path.
        match operator {
            "+" => left_val.add(&right_val),
            "-" => left_val.subtract(&right_val),
            "*" => left_val.multiply(&right_val),
            "/" => left_val.divide(&right_val),
            "%" => Ok(DixValue::from_double(
                left_val.as_double() % right_val.as_double(),
            )),
            "**" => Ok(DixValue::from_double(
                left_val.as_double().powf(right_val.as_double()),
            )),
            _ => Err(format!("Unknown arithmetic operator: {}", operator)),
        }
            .map_err(|e| {
                if e.contains("zero") {
                    InterpreterError::DivisionByZero { position }
                } else {
                    InterpreterError::InvalidOperation { message: e, position }
                }
            })
    }

    fn evaluate_bitwise_op(
        &mut self,
        arena: &Arena,
        left: ExprId,
        operator: &str,
        right: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let left_val  = self.evaluate_expression(arena, left,  context, scope_context, namespace)?;
        let right_val = self.evaluate_expression(arena, right, context, scope_context, namespace)?;

        if !left_val.is_numeric() || !right_val.is_numeric() {
            return Err(InterpreterError::InvalidOperation {
                message: format!(
                    "Bitwise operator '{}' requires numeric operands, got {} and {}",
                    operator,
                    left_val.get_type().get_type_name(),
                    right_val.get_type().get_type_name()
                ),
                position,
            });
        }

        // If either operand is Long use 64-bit arithmetic; otherwise stay at 32-bit.
        let use_long = left_val.get_type() == DixType::Long
            || right_val.get_type() == DixType::Long;

        if use_long {
            let lv = left_val.as_long();
            let rv = right_val.as_long();
            let result = match operator {
                "<<" => lv << rv,
                ">>" => lv >> rv,
                "&"  => lv & rv,
                "|"  => lv | rv,
                "^"  => lv ^ rv,
                _ => {
                    return Err(InterpreterError::InvalidOperation {
                        message: format!("Unknown bitwise operator: {}", operator),
                        position,
                    })
                }
            };
            Ok(DixValue::from_long(result))
        } else {
            let lv = left_val.as_int();
            let rv = right_val.as_int();
            let result = match operator {
                "<<" => lv << rv,
                ">>" => lv >> rv,
                "&"  => lv & rv,
                "|"  => lv | rv,
                "^"  => lv ^ rv,
                _ => {
                    return Err(InterpreterError::InvalidOperation {
                        message: format!("Unknown bitwise operator: {}", operator),
                        position,
                    })
                }
            };
            Ok(DixValue::from_int(result))
        }
    }

    fn evaluate_circular_modulo(
        &mut self,
        arena: &Arena,
        left: ExprId,
        right: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let left_val  = self.evaluate_expression(arena, left,  context, scope_context, namespace)?;
        let right_val = self.evaluate_expression(arena, right, context, scope_context, namespace)?;

        if !left_val.is_numeric() || !right_val.is_numeric() {
            return Err(InterpreterError::InvalidOperation {
                message: "Circular modulo requires numeric operands".to_string(),
                position,
            });
        }

        let lt = left_val.get_type();
        let rt = right_val.get_type();

        // Integer-only path: preserves Long precision
        let is_integer_only = matches!(lt, DixType::Int | DixType::Long)
            && matches!(rt, DixType::Int | DixType::Long);

        if is_integer_only {
            let a  = left_val.as_long();
            let b  = right_val.as_long();
            if b == 0 {
                return Err(InterpreterError::DivisionByZero { position });
            }
            let result = ((a % b) + b) % b;
            return Ok(if lt == DixType::Long || rt == DixType::Long {
                DixValue::from_long(result)
            } else {
                DixValue::from_int(result as i32)
            });
        }

        let a = left_val.as_double();
        let b = right_val.as_double();
        let result = ((a % b) + b) % b;

        Ok(if lt == DixType::Float || rt == DixType::Float {
            DixValue::from_float(result as f32)
        } else {
            DixValue::from_double(result)
        })
    }

    fn evaluate_percentage(
        &mut self,
        arena: &Arena,
        amount: ExprId,
        percentage: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let amount_val =
            self.evaluate_expression(arena, amount, context, scope_context, namespace)?;
        let percentage_val =
            self.evaluate_expression(arena, percentage, context, scope_context, namespace)?;

        if !amount_val.is_numeric() || !percentage_val.is_numeric() {
            return Err(InterpreterError::InvalidOperation {
                message: "Percentage operator requires numeric operands".to_string(),
                position,
            });
        }

        let result = (amount_val.as_double() * percentage_val.as_double()) / 100.0;

        Ok(
            if amount_val.get_type() == DixType::Int
                && percentage_val.get_type() == DixType::Int
            {
                DixValue::from_int(result as i32)
            } else if amount_val.get_type() == DixType::Float
                || percentage_val.get_type() == DixType::Float
            {
                DixValue::from_float(result as f32)
            } else {
                DixValue::from_double(result)
            },
        )
    }

    fn evaluate_bitwise_modulo(
        &mut self,
        arena: &Arena,
        left: ExprId,
        right: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let left_val  = self.evaluate_expression(arena, left,  context, scope_context, namespace)?;
        let right_val = self.evaluate_expression(arena, right, context, scope_context, namespace)?;

        if !left_val.is_numeric() || !right_val.is_numeric() {
            return Err(InterpreterError::InvalidOperation {
                message: "Bitwise modulo requires numeric operands".to_string(),
                position,
            });
        }

        let use_long = left_val.get_type() == DixType::Long
            || right_val.get_type() == DixType::Long;

        if use_long {
            let rv = right_val.as_long();
            if rv <= 0 {
                return Err(InterpreterError::InvalidOperation {
                    message: "Bitwise modulo (&%) requires a positive right operand".to_string(),
                    position,
                });
            }
            Ok(DixValue::from_long(left_val.as_long() & (rv - 1)))
        } else {
            let rv = right_val.as_int();
            if rv <= 0 {
                return Err(InterpreterError::InvalidOperation {
                    message: "Bitwise modulo (&%) requires a positive right operand".to_string(),
                    position,
                });
            }
            Ok(DixValue::from_int(left_val.as_int() & (rv - 1)))
        }
    }

    fn evaluate_comparison_op(
        &mut self,
        arena: &Arena,
        left: ExprId,
        operator: &str,
        right: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let left_val =
            self.evaluate_expression(arena, left, context, scope_context, namespace)?;
        let right_val =
            self.evaluate_expression(arena, right, context, scope_context, namespace)?;

        let result: Result<bool, InterpreterError> = match operator {
            "==" => Ok(left_val.equal_to(&right_val)),
            "!=" => Ok(!left_val.equal_to(&right_val)),
            "<" => left_val.less_than(&right_val).map_err(|e| {
                InterpreterError::InvalidOperation { message: e, position }
            }),
            ">" => left_val.greater_than(&right_val).map_err(|e| {
                InterpreterError::InvalidOperation { message: e, position }
            }),
            "<=" => {
                let less = left_val
                    .less_than(&right_val)
                    .map_err(|e| InterpreterError::InvalidOperation { message: e, position })?;
                Ok(less || left_val.equal_to(&right_val))
            }
            ">=" => {
                let greater = left_val
                    .greater_than(&right_val)
                    .map_err(|e| InterpreterError::InvalidOperation { message: e, position })?;
                Ok(greater || left_val.equal_to(&right_val))
            }
            _ => {
                return Err(InterpreterError::InvalidOperation {
                    message: format!("Unknown comparison operator: {}", operator),
                    position,
                })
            }
        };

        Ok(DixValue::from_bool(result?))
    }

    fn evaluate_logical_op(
        &mut self,
        arena: &Arena,
        left: ExprId,
        operator: &str,
        right: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let left_val =
            self.evaluate_expression(arena, left, context, scope_context, namespace)?;

        match operator {
            "&&" | "and" => {
                if !left_val.as_bool() {
                    return Ok(DixValue::from_bool(false));
                }
                let right_val =
                    self.evaluate_expression(arena, right, context, scope_context, namespace)?;
                Ok(DixValue::from_bool(right_val.as_bool()))
            }
            "||" | "or" => {
                if left_val.as_bool() {
                    return Ok(DixValue::from_bool(true));
                }
                let right_val =
                    self.evaluate_expression(arena, right, context, scope_context, namespace)?;
                Ok(DixValue::from_bool(right_val.as_bool()))
            }
            _ => Err(InterpreterError::InvalidOperation {
                message: format!("Unknown logical operator: {}", operator),
                position,
            }),
        }
    }

fn evaluate_unary_op(
        &mut self,
        arena: &Arena,
        operator: &str,
        operand: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let operand_val =
            self.evaluate_expression(arena, operand, context, scope_context, namespace)?;

        match operator {
            // ── CRITICAL FIX: unary `+` is the identity for numeric types ──────
            "+" => {
                if !operand_val.is_numeric() {
                    return Err(InterpreterError::InvalidOperation {
                        message: format!(
                            "Unary '+' requires a numeric type, got {:?}",
                            operand_val.get_type()
                        ),
                        position,
                    });
                }
                Ok(operand_val)
            }

            "-" => {
                if !operand_val.is_numeric() {
                    return Err(InterpreterError::InvalidOperation {
                        message: "Cannot negate non-numeric value".to_string(),
                        position,
                    });
                }
                Ok(match operand_val.get_type() {
                    DixType::Long   => DixValue::from_long(-operand_val.as_long()),
                    DixType::Int    => DixValue::from_int(-operand_val.as_int()),
                    DixType::Float  => DixValue::from_float(-operand_val.as_float()),
                    _               => DixValue::from_double(-operand_val.as_double()),
                })
            }
            "!" | "not" => Ok(DixValue::from_bool(!operand_val.as_bool())),
            "++" => {
                if !operand_val.is_numeric() {
                    return Err(InterpreterError::InvalidOperation {
                        message: "Cannot increment non-numeric value".to_string(),
                        position,
                    });
                }
                Ok(match operand_val.get_type() {
                    DixType::Long  => DixValue::from_long(operand_val.as_long().wrapping_add(1)),
                    DixType::Int   => DixValue::from_int(operand_val.as_int().wrapping_add(1)),
                    DixType::Float => DixValue::from_float(operand_val.as_float() + 1.0),
                    _              => DixValue::from_double(operand_val.as_double() + 1.0),
                })
            }
            "--" => {
                if !operand_val.is_numeric() {
                    return Err(InterpreterError::InvalidOperation {
                        message: "Cannot decrement non-numeric value".to_string(),
                        position,
                    });
                }
                Ok(match operand_val.get_type() {
                    DixType::Long  => DixValue::from_long(operand_val.as_long().wrapping_sub(1)),
                    DixType::Int   => DixValue::from_int(operand_val.as_int().wrapping_sub(1)),
                    DixType::Float => DixValue::from_float(operand_val.as_float() - 1.0),
                    _              => DixValue::from_double(operand_val.as_double() - 1.0),
                })
            }
            "~?" => {
                if !operand_val.is_numeric() {
                    return Err(InterpreterError::InvalidOperation {
                        message: "Bitwise NOT requires numeric operand".to_string(),
                        position,
                    });
                }
                Ok(match operand_val.get_type() {
                    DixType::Long => DixValue::from_long(!operand_val.as_long()),
                    _             => DixValue::from_int(!operand_val.as_int()),
                })
            }
            _ => Err(InterpreterError::InvalidOperation {
                message: format!("Unknown unary operator: {}", operator),
                position,
            }),
        }
    }

    fn evaluate_conditional(
        &mut self,
        arena: &Arena,
        condition: ExprId,
        true_value: ExprId,
        false_value: ExprId,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let cond =
            self.evaluate_expression(arena, condition, context, scope_context, namespace)?;

        if cond.as_bool() {
            self.evaluate_expression(arena, true_value, context, scope_context, namespace)
        } else {
            self.evaluate_expression(arena, false_value, context, scope_context, namespace)
        }
    }

    fn evaluate_static_method_call(
        &mut self,
        arena: &Arena,
        object_name: &str,
        method_name: &str,
        arguments: ExprList,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_verbose {
            self.error_manager.log_debug(&format!(
                "[StaticMethodCall] {}.{} with {} args",
                object_name,
                method_name,
                arguments.len()
            ));
        }

        let mut args = Vec::with_capacity(arguments.len());
        for (i, &arg) in arena.expr_list(arguments).iter().enumerate() {
            let val =
                self.evaluate_expression(arena, arg, context, scope_context, namespace)?;
            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "[StaticMethodCall] Arg[{}]: {} = {}",
                    i,
                    val.get_type().get_type_name(),
                    val
                ));
            }
            args.push(val);
        }

        builtin_call_resolver::resolve_static_call(object_name, method_name, &args)
            .map_err(|e| InterpreterError::BuiltinCallFailed {
                object: object_name.to_string(),
                method: method_name.to_string(),
                message: e,
                position,
            })
    }
    fn evaluate_instance_method_call(
        &mut self,
        arena:         &Arena,
        instance:      InstanceSource<'_>,
        method_name:   &str,
        arguments:     ExprList,
        position:      Position,
        context:       &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace:     Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let instance_val = match instance {
            InstanceSource::Expr(id) => {
                self.evaluate_expression(arena, id, context, scope_context, namespace)?
            }
            InstanceSource::Identifier(name, at) => {
                self.resolve_identifier(name, at, context, scope_context)?
            }
        };

        // ── Fix A: String lambda ref as instance ───────────────────────────────
        // Triggered by: `arr[0](x)`, `operations[0](x)`, etc.
        // `arr[0]` returns DixValue::String("__lam_N").  The subsequent `(x)` call
        // is parsed as InstanceMethodCall with synthetic method name "call".
        // Without this the builtin resolver receives a String and fails:
        //   "Type String has no method: call"
        if instance_val.get_type() == DixType::String {
            if let Some(val_str) = lambda_key(&instance_val) {
                if let Some(lambda) = self.lambda_registry.get(&val_str).cloned() {
                    if self.debug_config.is_enabled {
                        self.error_manager.log_debug(&format!(
                            "[InstanceMethodCall] Lambda ref '{}' invoked via '{}()'",
                            val_str, method_name
                        ));
                    }
                    return self.invoke_lambda(
                        arena, &lambda, arguments, position, context, scope_context, namespace,
                    );
                }
                return Err(InterpreterError::UndefinedFunction {
                    name:     format!("<lambda ref '{}' not in registry>", val_str),
                    position,
                });
            }
        }

        // ── Fix B: Object property is a lambda ref ─────────────────────────────
        // Triggered by: `calculator.add(x, 10)` where `add` is a stored lambda.
        // `calculator` resolves to an Object whose property "add" holds "__lam_N".
        // The builtin resolver has no user-defined lambda methods, so it fails.
        // Extract the key in a scoped block so the borrow of instance_val ends
        // before we need &mut self for invoke_lambda.
        if instance_val.get_type() == DixType::Object {
            let property_lambda: Option<String> = {
                let obj_map = instance_val.as_object();
                obj_map.get(method_name).and_then(|prop_val| {
                    if prop_val.get_type() == DixType::String {
                        let s = prop_val.as_string();
                        if s.starts_with("__lam_") { Some(s) } else { None }
                    } else {
                        None
                    }
                })
            };
            if let Some(key) = property_lambda {
                if let Some(lambda) = self.lambda_registry.get(&key).cloned() {
                    if self.debug_config.is_enabled {
                        self.error_manager.log_debug(&format!(
                            "[InstanceMethodCall] Object property lambda '{}' invoked",
                            method_name
                        ));
                    }
                    return self.invoke_lambda(
                        arena, &lambda, arguments, position, context, scope_context, namespace,
                    );
                }
            }
        }

        let mut args = Vec::with_capacity(arguments.len());
        for &arg in arena.expr_list(arguments) {
            args.push(
                self.evaluate_expression(arena, arg, context, scope_context, namespace)?,
            );
        }

        builtin_call_resolver::resolve_instance_call(&instance_val, method_name, &args)
            .map_err(|e| InterpreterError::BuiltinCallFailed {
                object: format!("{:?}", instance_val.get_type()),
                method: method_name.to_string(),
                message: e,
                position,
            })
    }

    fn evaluate_property_access(
        &mut self,
        arena: &Arena,
        object: ExprId,
        property: &str,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let obj =
            self.evaluate_expression(arena, object, context, scope_context, namespace)?;

        if obj.get_type() != DixType::Object {
            return Err(InterpreterError::InvalidOperation {
                message: format!(
                    "Cannot access property '{}' on non-object type {}",
                    property,
                    obj.get_type().get_type_name()
                ),
                position,
            });
        }

        obj.as_object()
            .get(property)
            .cloned()
            .ok_or_else(|| InterpreterError::PropertyNotFound {
                property: property.to_string(),
                position,
            })
    }

    fn evaluate_index_access(
        &mut self,
        arena: &Arena,
        object: ExprId,
        index: ExprId,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let obj =
            self.evaluate_expression(arena, object, context, scope_context, namespace)?;
        let idx =
            self.evaluate_expression(arena, index, context, scope_context, namespace)?;

        match obj.get_type() {
            DixType::Array | DixType::Tuple => {
                let array = obj.as_array();
                let index_val = idx.as_int() as usize;
                if index_val >= array.len() {
                    return Err(InterpreterError::IndexOutOfBounds {
                        index: index_val as i64,
                        length: array.len(),
                        position,
                    });
                }
                Ok(array[index_val].clone())
            }
            DixType::Object => {
                let key = idx.as_string();
                obj.as_object()
                    .get(&key)
                    .cloned()
                    .ok_or(InterpreterError::PropertyNotFound {
                        property: key,
                        position,
                    })
            }
            DixType::String => {
                let s = obj.as_string();
                let index_val = idx.as_int() as usize;
                if index_val >= s.len() {
                    return Err(InterpreterError::IndexOutOfBounds {
                        index: index_val as i64,
                        length: s.len(),
                        position,
                    });
                }
                Ok(DixValue::from_string(
                    s.chars().nth(index_val).unwrap().to_string(),
                ))
            }
            _ => Err(InterpreterError::InvalidOperation {
                message: format!(
                    "Cannot index type {}",
                    obj.get_type().get_type_name()
                ),
                position,
            }),
        }
    }

fn evaluate_enum_access(
    &self,
    namespace_name: Option<&str>,
    enum_name: &str,
    value: &str,
    position: Position,
    namespace: Option<&ImportedNamespace>,
) -> Result<DixValue, InterpreterError> {
    if let Some(ns_name) = namespace_name {
        if self.debug_config.is_enabled {
            self.error_manager.log_debug(&format!(
                "[EnumAccess] Imported: {}.{}.{}",
                ns_name, enum_name, value
            ));
        }

        let ns = self
            .resolve_namespace(ns_name, namespace)
            .ok_or_else(|| InterpreterError::NamespaceNotFound {
                name: ns_name.to_string(),
                position,
            })?;

        let enum_fields = ns.enums.get(enum_name).ok_or_else(|| {
            InterpreterError::InvalidEnumAccess {
                location: format!("{}.{}.{}", ns_name, enum_name, value),
                position,
            }
        })?;

        let field_value = enum_fields.get(value).ok_or_else(|| {
            InterpreterError::InvalidEnumAccess {
                location: format!("{}.{}.{}", ns_name, enum_name, value),
                position,
            }
        })?;

        return Ok(DixValue::from_int(*field_value));
    }

    // FIX: when executing inside an imported namespace function, that namespace's
    // own @ENUMS are not in self.symbol_table (the caller's table). Check the
    // current execution namespace's enums first before falling back globally.
    if let Some(current_ns) = namespace {
        if let Some(fields) = current_ns.enums.get(enum_name) {
            if let Some(&int_val) = fields.get(value) {
                if self.debug_config.is_verbose {
                    self.error_manager.log_debug(&format!(
                        "[EnumAccess] Resolved '{}' from current namespace enums",
                        format!("{}.{}", enum_name, value)
                    ));
                }
                return Ok(DixValue::from_int(int_val));
            }
        }
    }

    // Fall back to the global (caller's) symbol table for locally-defined enums.
    self.symbol_table
        .try_get_enum_field_value(enum_name, value)
        .map(DixValue::from_int)
        .ok_or_else(|| InterpreterError::InvalidEnumAccess {
            location: format!("{}.{}", enum_name, value),
            position,
        })
}

    fn evaluate_config_access(
        &self,
        key: &str,
        position: Position,
    ) -> Result<DixValue, InterpreterError> {
        self.symbol_table
            .get_config(key)
            .map(|s| DixValue::from_string(s.clone()))
            .ok_or_else(|| InterpreterError::ConfigKeyNotFound {
                key: key.to_string(),
                position,
            })
    }

    // =========================================================================
    // THE FIX: evaluate_quick_func_call and evaluate_imported_function_call
    //
    // Root cause: arguments were raw Expression nodes evaluated inside the
    // callee's empty context. They must be evaluated in the CALLER's context
    // first, then passed as already-resolved Value nodes to the callee.
    // =========================================================================

    fn evaluate_quick_func_call(
        &mut self,
        arena:         &Arena,
        name:          &str,
        arguments:     ExprList,
        position:      Position,
        context:       &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace:     Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        // 1. Lambda registry by name (covers direct declarations and re-registered
        //    lambdas from higher-order functions via execute_variable_declaration).
        if let Some(lambda) = self.lambda_registry.get(name).cloned() {
            if self.debug_config.is_enabled {
                self.error_manager.log_debug(&format!("[Lambda] Invoking '{}' from registry", name));
            }
            return self.invoke_lambda(arena, &lambda, arguments, position, context, scope_context, namespace);
        }

        // 2. Check whether `name` is a local variable holding a lambda reference key.
        //    This handles lambdas received as function parameters (e.g. the `fn`
        //    parameter of `let apply = (n, fn) => fn(n)`) and lambdas that were
        //    returned from other functions but not re-registered under their new name
        //    in any prior assignment path.
        if let Ok(context_val) = context.get_variable(name) {
            if let Some(val_str) = lambda_key(&context_val) {
                if let Some(lambda) = self.lambda_registry.get(&val_str).cloned() {
                    if self.debug_config.is_enabled {
                        self.error_manager.log_debug(&format!(
                            "[Lambda] Invoking '{}' via context reference key {}",
                            name, val_str
                        ));
                    }
                    return self.invoke_lambda(
                        arena, &lambda, arguments, position, context, scope_context, namespace,
                    );
                }
            }
        }

        // Evaluate all arguments in the CALLER's context before constructing the
        // callee's context so parameter names from the callee's signature are never
        // looked up in an empty execution context during bind_parameters.
        let evaluated_args = self.evaluate_arguments_in_caller_context(
            arena, arguments, position, context, scope_context, namespace,
        )?;
        let call_args = CallArgs { values: &evaluated_args, wrap: Wrap::Body, position };

        // 3. Current namespace functions.
        if let Some(ns) = namespace {
            if let Some(function) = self
                .imported_functions
                .get(&namespace_key(ns))
                .and_then(|table| table.get(name))
                .cloned()
            {
                if self.debug_config.is_enabled {
                    self.error_manager.log_debug(&format!(
                        "[QuickFuncCall] Found '{}' in current namespace",
                        name
                    ));
                }
                let mut nested_context = scope_for(name, &function);
                return self.execute(
                    arena,
                    &function,
                    call_args,
                    &mut nested_context,
                    scope_context,
                    namespace,
                );
            }
        }

        // 4. Global quick-functions registry.
        let function = self
            .quick_functions
            .get(name)
            .cloned()
            .ok_or_else(|| InterpreterError::UndefinedFunction {
                name:     name.to_string(),
                position,
            })?;

        let mut nested_context = scope_for(name, &function);
        self.execute(arena, &function, call_args, &mut nested_context, scope_context, None)
    }

    fn evaluate_imported_function_call(
        &mut self,
        arena:         &Arena,
        namespace_name: &str,
        function_name: &str,
        arguments:     ExprList,
        position:      Position,
        context:       &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_enabled {
            self.error_manager.log_debug(&format!(
                "[ImportedCall] {}.{}",
                namespace_name, function_name
            ));
        }

        // FIX: evaluate all arguments in the CALLER's context first.
        // The callee is in a different namespace and its execution context
        // starts empty - it cannot see the caller's local variables.
        let evaluated_args = self.evaluate_arguments_in_caller_context(
            arena, arguments, position, context, scope_context, None,
        )?;

        let ns = self
            .resolve_namespace(namespace_name, None)
            .ok_or_else(|| InterpreterError::NamespaceNotFound {
                name: namespace_name.to_string(),
                position,
            })?;

        let function = self
            .imported_functions
            .get(&namespace_key(ns))
            .and_then(|table| table.get(function_name))
            .cloned()
            .ok_or_else(|| InterpreterError::FunctionNotInNamespace {
                namespace: namespace_name.to_string(),
                function: function_name.to_string(),
                position,
            })?;

        let fqn = format!("{}.{}", namespace_name, function_name);
        let mut imported_context = scope_for(&fqn, &function);

        self.execute(
            arena,
            &function,
            CallArgs { values: &evaluated_args, wrap: Wrap::Body, position },
            &mut imported_context,
            scope_context,
            Some(ns),
        )
    }

    /// Runs the call of a function found in `@DATA`, `namespace_name` being the alias of an
    /// imported namespace for an imported function.
    ///
    /// The arguments are evaluated in an empty top-level context, converted the way calls from
    /// `@DATA` always were (see [`Wrap::Data`]), and bound to the function's parameters.
    pub fn execute_data_call(
        &mut self,
        arena:          &Arena,
        function_name:  &str,
        namespace_name: Option<&str>,
        arguments:      ExprList,
        position:       Position,
        scope_context:  &FxHashMap<String, String>,
    ) -> Result<DixValue, InterpreterError> {
        // At DATA level there are no local variables - create an empty top-level
        // context. The interpreter resolves identifiers via data_context.
        let mut top_level_ctx = ExecutionContext::new("<data>", None);

        // Evaluate every argument in the top-level context. This correctly handles
        // nested ImportedFunctionCalls, QuickFuncCalls, arithmetic, enum accesses -
        // anything the interpreter knows how to evaluate.
        let evaluated_args = self.evaluate_arguments_in_caller_context(
            arena,
            arguments,
            position,
            &mut top_level_ctx,
            scope_context,
            None,
        )?;
        let call_args = CallArgs { values: &evaluated_args, wrap: Wrap::Data, position };

        match namespace_name {
            Some(ns_name) => {
                let undefined = || InterpreterError::UndefinedFunction {
                    name: format!("{}.{}", ns_name, function_name),
                    position,
                };
                let ns = self.symbol_table.try_get_namespace(ns_name).ok_or_else(undefined)?;
                let function = self
                    .imported_functions
                    .get(&namespace_key(ns))
                    .and_then(|table| table.get(function_name))
                    .cloned()
                    .ok_or_else(undefined)?;

                let fqn = format!("{}.{}", ns_name, function_name);
                let mut ctx = scope_for(&fqn, &function);
                self.execute(arena, &function, call_args, &mut ctx, scope_context, Some(ns))
            }

            None => {
                let function = self
                    .quick_functions
                    .get(function_name)
                    .cloned()
                    .ok_or_else(|| InterpreterError::UndefinedFunction {
                        name: function_name.to_string(),
                        position,
                    })?;

                let mut ctx = scope_for(function_name, &function);
                self.execute(arena, &function, call_args, &mut ctx, scope_context, None)
            }
        }
    }

    // =========================================================================
    // Helpers for the fixed call sites
    // =========================================================================

    /// Evaluate every argument expression in the *caller's* context, returning
    /// a vec of resolved DixValues. Called before constructing any callee context.
    pub fn evaluate_arguments_in_caller_context(
        &mut self,
        arena: &Arena,
        arguments: ExprList,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<Vec<DixValue>, InterpreterError> {
        let mut evaluated = Vec::with_capacity(arguments.len());
        for (i, &arg) in arena.expr_list(arguments).iter().enumerate() {
            let val = self
                .evaluate_expression(arena, arg, context, scope_context, namespace)
                .map_err(|e| InterpreterError::ParameterEvalFailed {
                    index: i,
                    param_name: format!("arg{}", i),
                    inner: Box::new(e),
                    position: arena.expr(arg).position(),
                })?;
            evaluated.push(val);
        }
        Ok(evaluated)
    }

    fn invoke_lambda(
        &mut self,
        arena:         &Arena,
        lambda:        &LambdaAst,
        arguments:     ExprList,
        position:      Position,
        context:       &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace:     Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if lambda.params.len() != arguments.len() {
            return Err(InterpreterError::LambdaParamMismatch {
                expected: lambda.params.len(),
                got:      arguments.len(),
                position,
            });
        }

        let mut lambda_context = ExecutionContext::new("<lambda>", None);

        // Restore the closure-captured environment first so that variables from
        // outer scopes (e.g. `x` and `multiplier` in a nested lambda) are visible
        // inside the lambda body.  Parameters are bound below and override any
        // captured variable that shares the same name.
        if let Some(ref captured) = lambda.captured_env {
            for (var_name, val) in captured {
                // A fresh context has no variables yet, so define_variable will not
                // fail here.  The let-binding suppresses the unused-result warning.
                let _ = lambda_context.define_variable(var_name, val.clone());
            }
        }

        // Evaluate each argument in the CALLER's context (not lambda_context) so
        // that identifier resolution uses the scope where the call was made.
        let argument_ids = arena.expr_list(arguments);
        for (i, &param) in arena.str_list(lambda.params).iter().enumerate() {
            let param_name = arena.text(param);
            let arg_value = self
                .evaluate_expression(arena, argument_ids[i], context, scope_context, namespace)
                .map_err(|e| InterpreterError::ParameterEvalFailed {
                    index:      i,
                    param_name: param_name.to_string(),
                    inner:      Box::new(e),
                    position,
                })?;

            // If the parameter name was already populated from the captured env,
            // update (set) it rather than re-defining to avoid a duplicate error.
            if lambda_context.has_variable(param_name) {
                lambda_context
                    .set_variable(param_name, arg_value)
                    .map_err(|e| InterpreterError::InvalidOperation {
                        message:  e.to_string(),
                        position,
                    })?;
            } else {
                lambda_context
                    .define_variable(param_name, arg_value)
                    .map_err(|e| InterpreterError::InvalidOperation {
                        message:  e.to_string(),
                        position,
                    })?;
            }
        }

        // Block-body lambda: drive execution through statements and honour explicit
        // return statements.
        if !lambda.statements.is_empty() {
            let mut last_result = DixValue::null();
            for &stmt in arena.stmt_list(lambda.statements) {
                last_result = self.execute_statement(
                    arena, stmt, &mut lambda_context, scope_context, namespace,
                )?;
                if matches!(arena.stmt(stmt), StmtNode::Return { .. }) {
                    return Ok(last_result);
                }
            }
            return Ok(last_result);
        }

        // Single-expression body.
        self.evaluate_expression(
            arena,
            lambda.body,
            &mut lambda_context,
            scope_context,
            namespace,
        )
    }

    fn resolve_namespace(
        &self,
        namespace_name: &str,
        current_namespace: Option<&'a ImportedNamespace>,
    ) -> Option<&'a ImportedNamespace> {
        if let Some(ns) = self.symbol_table.try_get_namespace(namespace_name) {
            return Some(ns);
        }
        if let Some(current_ns) = current_namespace {
            if let Some(local_ns) = current_ns.local_imports.get(namespace_name) {
                return Some(local_ns);
            }
        }
        None
    }

    fn convert_ast_value_to_dix_value(
        &mut self,
        arena: &Arena,
        value: ValueId,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        match *arena.value(value) {
            ValueNode::Expression { expr, .. } => {
                self.evaluate_expression(arena, expr, context, scope_context, namespace)
            }
            ValueNode::Integer { value, .. }            => Ok(DixValue::from_int(value)),
            ValueNode::Long { value, .. }               => Ok(DixValue::from_long(value)),
            ValueNode::Float { value, .. }              => Ok(DixValue::from_float(value)),
            ValueNode::Double { value, .. }             => Ok(DixValue::from_double(value)),
            ValueNode::ScientificNotation { value, .. } => Ok(DixValue::from_double(value)),
            ValueNode::String { value, .. }             => Ok(DixValue::from_string(arena.text(value).to_string())),
            ValueNode::Boolean { value, .. }            => Ok(DixValue::from_bool(value)),
            ValueNode::Null { .. }                      => Ok(DixValue::null()),
            ValueNode::HexColor { value, .. }           => Ok(DixValue::from_hex(arena.text(value).to_string())),

            ValueNode::Array { values, position }
            | ValueNode::NestedArray { values, position, .. } => {
                self.convert_array(arena, values, position, context, scope_context, namespace)
            }

            ValueNode::Object { properties, position } => {
                self.convert_object_literal(
                    arena, properties, position, context, scope_context, namespace,
                )
            }

            ValueNode::PrefixedConstructor { prefix, arguments, position } => {
                self.convert_prefixed_constructor(
                    arena, arena.text(prefix), arguments, position, context, scope_context, namespace,
                )
            }

            // FIX: lambdas are now first-class values.
            // Each lambda definition gets a unique reference key ("__lam_N") that is
            // stored as the DixValue.  The definition (handles into the arena), together
            // with a snapshot of the current execution context (for closure support), is
            // stored in the lambda registry under that key.  The key is also registered
            // under the variable name by execute_variable_declaration / execute_assignment
            // so that direct calls like `myLambda(args)` still work via the registry name
            // lookup.
            ValueNode::Lambda { parameters, body, statements, .. } => {
                // Capture the current environment for closure semantics.
                let captured = context.get_all_variables();

                let key = format!("__lam_{}", self.lambda_counter);
                self.lambda_counter += 1;

                self.lambda_registry.insert(key.clone(), Rc::new(LambdaAst {
                    params:       parameters,
                    body,
                    statements,
                    captured_env: if captured.is_empty() { None } else { Some(captured) },
                }));

                if self.debug_config.is_verbose {
                    let names: Vec<&str> =
                        arena.str_list(parameters).iter().map(|&s| arena.text(s)).collect();
                    self.error_manager.log_debug(&format!(
                        "[Lambda] Registered under key {} (params: {:?})",
                        key, names
                    ));
                }

                Ok(DixValue::from_string(key))
            }

            ValueNode::QuickFuncCall { function_name, arguments, position } => {
                self.evaluate_quick_func_call(
                    arena, arena.text(function_name), arguments, position, context, scope_context, namespace,
                )
            }

            ValueNode::InterpolatedString { template, expressions, position } => {
                self.evaluate_interpolated_string(
                    arena, arena.text(template), expressions, position, context, scope_context, namespace,
                )
            }

            ValueNode::EnumValue { enum_name, value: enum_value, position } => {
                self.evaluate_enum_access(
                    None, arena.text(enum_name), arena.text(enum_value), position, namespace,
                )
            }

            ValueNode::Identifier { value: id_value, position } => {
                self.resolve_identifier(arena.text(id_value), position, context, scope_context)
            }

            ValueNode::Date { value, .. } => date_value(arena.text(value)),

            ValueNode::Timestamp { value, .. } => timestamp_value(arena.text(value)),

            _ => Err(InterpreterError::InvalidOperation {
                message: format!("Unsupported value type: {}", value_variant_name(arena.value(value))),
                position: Position::UNKNOWN,
            }),
        }
    }

    fn convert_array(
        &mut self,
        arena: &Arena,
        values: ValueList,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let mut dix_values = Vec::with_capacity(values.len());
        for &value in arena.value_list(values) {
            dix_values.push(
                self.convert_ast_value_to_dix_value(arena, value, context, scope_context, namespace)?,
            );
        }
        Ok(DixValue::from_array(dix_values))
    }

    fn convert_object_literal(
        &mut self,
        arena: &Arena,
        properties: PropList,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let mut dix_obj = HashMap::with_capacity(properties.len());
        for prop in arena.prop_list(properties) {
            let value = self.convert_ast_value_to_dix_value(
                arena, prop.value, context, scope_context, namespace,
            )?;
            dix_obj.insert(arena.text(prop.key).to_string(), value);
        }
        Ok(DixValue::from_object(dix_obj))
    }

    fn convert_prefixed_constructor(
        &mut self,
        arena: &Arena,
        prefix: &str,
        arguments: ValueList,
        position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        let args = arena.value_list(arguments);
        match prefix.to_lowercase().as_str() {
            "t" => {
                let cap = args.len().min(6);
                let mut tuple_values = Vec::with_capacity(cap);
                for &arg in args.iter().take(6) {
                    tuple_values.push(self.convert_ast_value_to_dix_value(
                        arena, arg, context, scope_context, namespace,
                    )?);
                }
                Ok(DixValue::from_tuple(tuple_values))
            }
            "b" => {
                let base64_data = if args.is_empty() {
                    String::new()
                } else {
                    match *arena.value(args[0]) {
                        ValueNode::String { value, .. } => arena.text(value).to_string(),
                        _ => self
                            .convert_ast_value_to_dix_value(
                                arena, args[0], context, scope_context, namespace,
                            )?
                            .as_string(),
                    }
                };
                DixValue::from_blob(base64_data).map_err(|e| {
                    InterpreterError::InvalidOperation { message: e, position }
                })
            }
            "r" => {
                let pattern = if args.is_empty() {
                    ".*".to_string()
                } else {
                    match *arena.value(args[0]) {
                        ValueNode::String { value, .. } => arena.text(value).to_string(),
                        _ => self
                            .convert_ast_value_to_dix_value(
                                arena, args[0], context, scope_context, namespace,
                            )?
                            .as_string(),
                    }
                };
                DixValue::from_regex(pattern).map_err(|e| {
                    InterpreterError::InvalidOperation { message: e, position }
                })
            }
            _ => Err(InterpreterError::InvalidOperation {
                message: format!("Unknown prefix constructor: {}", prefix),
                position,
            }),
        }
    }

    fn evaluate_interpolated_string(
        &mut self,
        arena: &Arena,
        template: &str,
        expressions: ExprList,
        _position: Position,
        context: &mut ExecutionContext,
        scope_context: &FxHashMap<String, String>,
        namespace: Option<&ImportedNamespace>,
    ) -> Result<DixValue, InterpreterError> {
        if self.debug_config.is_verbose {
            self.error_manager.log_debug(&format!(
                "[InterpolatedString] Template: '{}', expressions: {}",
                template,
                expressions.len()
            ));
        }

        let mut result = String::with_capacity(template.len() + expressions.len() * 8);
        result.push_str(template);

        for (i, &expr) in arena.expr_list(expressions).iter().enumerate() {
            let value =
                self.evaluate_expression(arena, expr, context, scope_context, namespace)?;
            let placeholder = format!("{{{}}}", i);
            let value_string = value.as_string();

            if self.debug_config.is_verbose {
                self.error_manager.log_debug(&format!(
                    "[InterpolatedString] Replacing '{}' with '{}'",
                    placeholder, value_string
                ));
            }

            result = result.replace(&placeholder, &value_string);
        }

        if self.debug_config.is_verbose {
            self.error_manager.log_debug(&format!(
                "[InterpolatedString] Result: '{}'",
                result
            ));
        }

        Ok(DixValue::from_string(result))
    }
}

// =============================================================================
// Diagnostic helpers - zero allocation, used only on debug/error paths
// =============================================================================

fn statement_variant_name(stmt: &StmtNode) -> &'static str {
    match stmt {
        StmtNode::Return { .. }              => "Return",
        StmtNode::Assignment { .. }          => "Assignment",
        StmtNode::ArithmeticAssignment { .. }=> "ArithmeticAssignment",
        StmtNode::If { .. }                  => "If",
        StmtNode::Switch { .. }              => "Switch",
        StmtNode::Log { .. }                 => "Log",
        StmtNode::VariableDeclaration { .. } => "VariableDeclaration",
        StmtNode::ExpressionStatement { .. } => "ExpressionStatement",
        StmtNode::ObjectCreation { .. }      => "ObjectCreation",
    }
}

fn value_variant_name(value: &ValueNode) -> &'static str {
    match value {
        ValueNode::Integer { .. }            => "Integer",
        ValueNode::Long { .. }               => "Long",
        ValueNode::Float { .. }              => "Float",
        ValueNode::Double { .. }             => "Double",
        ValueNode::ScientificNotation { .. } => "ScientificNotation",
        ValueNode::String { .. }             => "String",
        ValueNode::Boolean { .. }            => "Boolean",
        ValueNode::InterpolatedString { .. } => "InterpolatedString",
        ValueNode::HexColor { .. }           => "HexColor",
        ValueNode::Date { .. }               => "Date",
        ValueNode::Timestamp { .. }          => "Timestamp",
        ValueNode::Null { .. }               => "Null",
        ValueNode::Array { .. }              => "Array",
        ValueNode::NestedArray { .. }        => "NestedArray",
        ValueNode::Object { .. }             => "Object",
        ValueNode::PrefixedConstructor { .. }=> "PrefixedConstructor",
        ValueNode::EnumValue { .. }          => "EnumValue",
        ValueNode::Identifier { .. }         => "Identifier",
        ValueNode::QuickFuncCall { .. }      => "QuickFuncCall",
        ValueNode::Expression { .. }         => "Expression",
        ValueNode::Range { .. }              => "Range",
        ValueNode::Lambda { .. }             => "Lambda",
        ValueNode::ParseError { .. }         => "ParseError",
        ValueNode::Error { .. }              => "Error",
        ValueNode::Unknown { .. }            => "Unknown",
    }
}

fn expr_variant_name(expr: &ExprNode) -> &'static str {
    match expr {
        ExprNode::Identifier { .. }          => "Identifier",
        ExprNode::QualifiedIdentifier { .. } => "QualifiedIdentifier",
        ExprNode::FunctionCall { .. }        => "FunctionCall",
        ExprNode::QuickFuncCall { .. }       => "QuickFuncCall",
        ExprNode::DixFunctionCall { .. }     => "DixFunctionCall",
        ExprNode::StaticMethodCall { .. }    => "StaticMethodCall",
        ExprNode::InstanceMethodCall { .. }  => "InstanceMethodCall",
        ExprNode::BuiltinFunction { .. }     => "BuiltinFunction",
        ExprNode::StaticFunction { .. }      => "StaticFunction",
        ExprNode::ImportedFunctionCall { .. }=> "ImportedFunctionCall",
        ExprNode::ArithmeticOp { .. }        => "ArithmeticOp",
        ExprNode::BitwiseOp { .. }           => "BitwiseOp",
        ExprNode::ComparisonOp { .. }        => "ComparisonOp",
        ExprNode::LogicalOp { .. }           => "LogicalOp",
        ExprNode::UnaryOp { .. }             => "UnaryOp",
        ExprNode::ConfigAccess { .. }        => "ConfigAccess",
        ExprNode::EnumAccess { .. }          => "EnumAccess",
        ExprNode::ObjectAccess { .. }        => "ObjectAccess",
        ExprNode::PropertyAccess { .. }      => "PropertyAccess",
        ExprNode::IndexAccess { .. }         => "IndexAccess",
        ExprNode::Value { .. }               => "Value",
        ExprNode::Parenthesized { .. }       => "Parenthesized",
        ExprNode::Conditional { .. }         => "Conditional",
        ExprNode::TypeCast { .. }            => "TypeCast",
    }
}
