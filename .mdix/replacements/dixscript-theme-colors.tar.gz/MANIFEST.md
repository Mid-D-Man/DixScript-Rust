# Theme colors wiring — file manifest

Verified against real `Mid-D-Man/DixScript-Rust` `master` (cloned fresh this
session). 6 modified files, 1 new file.

## Modified
- `mdix-lsp/src/features/commands.rs` — adds `map_theme_key`, `has_theme_tables`,
  `run_get_theme_colors` (theme colors section at end of file)
- `mdix-lsp/src/features/code_lens.rs` — adds `CMD_GET_THEME_COLORS` (server,
  in ALL_COMMANDS) + `CMD_APPLY_THEME_COLORS` (client-only) + gated "🎨 Apply
  Theme" lens
- `mdix-lsp/src/server.rs` — imports + new `CMD_GET_THEME_COLORS` dispatch arm
  in `execute_command` (returns JSON directly, doesn't fall through to `Ok(None)`)
- `mdix-vscode/src/extension.ts` — imports + registers `registerThemeColors`
- `mdix-vscode/package.json` — adds `mdix.applyThemeColors` to `contributes.commands`
- `mdix-vscode/-_-master_colors.mdix` — corrected/completed example (was
  already committed, using bare `string`/`enum` keys with no `m_` prefix,
  10/3 dark/light keys, and a dead `@ENUMS(Theme{...})` block — replaced with
  the full 14-key `m_`-prefixed version, dead enum block removed)

## New
- `mdix-vscode/src/themeColors.ts` — client-side apply logic
