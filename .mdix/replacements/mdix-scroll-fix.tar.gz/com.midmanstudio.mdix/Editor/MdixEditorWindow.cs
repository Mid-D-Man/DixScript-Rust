using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using MidManStudio.Mdix.Core;
using MidManStudio.Mdix.Unity;

namespace MidManStudio.Mdix.Unity.Editor
{
    /// <summary>
    /// MDIX Studio — the main editor window.
    /// Four tabs: Explorer (compiled data viewer), Editor (source text), Search (find text in
    /// every .mdix file of the project), Templates (new file creation).
    /// Open via MidManStudio → MDIX Studio, or by double-clicking a .mdix asset.
    ///
    /// The window is split over several files: this one holds the shell (tabs, compile, save,
    /// documents), MdixEditorWindow.Explorer.cs the tree view, MdixEditorWindow.Search.cs the
    /// project search and MdixEditorWindow.Lsp.cs the language-server features.
    /// </summary>
    public sealed partial class MdixEditorWindow : EditorWindow
    {
        // ── Constants ─────────────────────────────────────────────────────────

        private const string UxmlPath =
            "Packages/com.midmanstudio.mdix/Editor/UI/MdixEditorWindow.uxml";
        private const string UssPath  =
            "Packages/com.midmanstudio.mdix/Editor/UI/MdixEditorWindow.uss";

        private const string PrefKeyLastPath = "MdixStudio_LastPath";

        // ── State ─────────────────────────────────────────────────────────────

        private MdixAsset?   _currentAsset;
        private string       _currentPath  = string.Empty;
        private string       _sourceText   = string.Empty;
        private bool         _isDirty;
        private int          _activeTab;   // 0 = Explorer, 1 = Editor, 2 = Templates, 3 = Search

        // UI element references
        private Label?         _titleLabel;
        private Label?         _fileLabel;
        private Label?         _statusLabel;
        private VisualElement? _panelExplorer;
        private VisualElement? _panelEditor;
        private VisualElement? _panelTemplates;
        private TextField?     _codeField;
        private Label?         _sbCompiled;
        private Label?         _sbEntries;
        private Label?         _sbFlatKeys;
        private Label?         _sbTables;
        private Label?         _sbPath;

        private VisualElement? _tabExplorer;
        private VisualElement? _tabEditor;
        private VisualElement? _tabTemplates;
        private Button?        _btnFoldAll;

        private VisualElement _tabSearch;
        private VisualElement _panelSearch;

        // ── Menu and entry points ─────────────────────────────────────────────

        [MenuItem("MidManStudio/MDIX Studio")]
        public static void Open()
        {
            var window = GetWindow<MdixEditorWindow>("MDIX Studio");
            window.minSize = new Vector2(600, 480);

            var lastPath = EditorPrefs.GetString(PrefKeyLastPath, string.Empty);
            if (!string.IsNullOrEmpty(lastPath))
            {
                // The menu item only brings the window forward: it must never replace edits
                // that haven't been saved.
                var asset = AssetDatabase.LoadAssetAtPath<MdixAsset>(lastPath);
                if (asset != null && !window._isDirty)
                    window.LoadAsset(asset);
            }
        }

        public static void OpenWithAsset(MdixAsset asset)
        {
            var window = GetWindow<MdixEditorWindow>("MDIX Studio");
            window.minSize = new Vector2(600, 480);

            if (window.ConfirmLeaveCurrentDocument(asset.ProjectRelativePath))
                window.LoadAsset(asset);
        }

        /// <summary>
        /// Double-clicking a .mdix asset opens it here (the README has always promised this).
        /// Returns false for anything else, so Unity's normal handling is left alone.
        /// </summary>
        [UnityEditor.Callbacks.OnOpenAsset(1)]
        public static bool OnOpenMdixAsset(int instanceID, int line)
        {
            var asset = EditorUtility.InstanceIDToObject(instanceID) as MdixAsset;
            if (asset == null) return false;

            OpenWithAsset(asset);
            return true;
        }

        /// <summary>
        /// True if it is fine to replace the document on screen with <paramref name="nextPath"/>.
        /// Opening another file used to overwrite unsaved edits without a word.
        /// </summary>
        private bool ConfirmLeaveCurrentDocument(string nextPath)
        {
            if (!_isDirty) return true;

            // Asked to open the file that is already open and edited: keep the edits, just show the window.
            if (string.Equals(_currentPath, nextPath, StringComparison.Ordinal)) return false;

            var scratch = string.IsNullOrEmpty(_currentPath);
            var name    = scratch ? "Untitled" : Path.GetFileName(_currentPath);

            var choice = EditorUtility.DisplayDialogComplex(
                "Unsaved Changes",
                $"'{name}' has unsaved changes. Save before opening '{Path.GetFileName(nextPath)}'?",
                "Save", "Cancel", "Discard");

            switch (choice)
            {
                case 0: // Save
                    if (scratch)
                        return PromptAndWriteNewFile() != null; // cancelled panel => stay put

                    SaveSource();
                    return !_isDirty;                           // a failed save => stay put

                case 2: // Discard
                    return true;

                default: // Cancel
                    return false;
            }
        }

        // ── UIElements lifecycle ──────────────────────────────────────────────

        public void CreateGUI()
        {
            var uxml = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(UxmlPath);
            if (uxml == null)
            {
                rootVisualElement.Add(new Label(
                    "MDIX Studio: UXML not found. " +
                    "Ensure the package is correctly installed."));
                return;
            }

            uxml.CloneTree(rootVisualElement);

            var uss = AssetDatabase.LoadAssetAtPath<StyleSheet>(UssPath);
            if (uss != null)
                rootVisualElement.styleSheets.Add(uss);

            BindElements();
            BuildTemplatesPanel();
            BuildSearchPanel();
            ShowTab(0);
        }

        private void BindElements()
        {
            var root = rootVisualElement;

            _titleLabel     = root.Q<Label>("title-label");
            _fileLabel      = root.Q<Label>("file-label");
            _statusLabel    = root.Q<Label>("status-label");
            _panelExplorer  = root.Q("panel-explorer");
            _panelEditor    = root.Q("panel-editor");
            _panelTemplates = root.Q("panel-templates");
            _sbCompiled     = root.Q<Label>("sb-compiled");
            _sbEntries      = root.Q<Label>("sb-entries");
            _sbFlatKeys     = root.Q<Label>("sb-flat-keys");
            _sbTables       = root.Q<Label>("sb-tables");
            _sbPath         = root.Q<Label>("sb-path");

            _tabExplorer  = root.Q("tab-explorer");
            _tabEditor    = root.Q("tab-editor");
            _tabTemplates = root.Q("tab-templates");

            _tabExplorer?.RegisterCallback<ClickEvent>(_ => ShowTab(0));
            _tabEditor?.RegisterCallback<ClickEvent>(_ => ShowTab(1));
            _tabTemplates?.RegisterCallback<ClickEvent>(_ => ShowTab(2));

            _tabSearch   = root.Q("tab-search");
            _panelSearch = root.Q("panel-search");
            _tabSearch?.RegisterCallback<ClickEvent>(_ => ShowTab(3));

            root.Q<Button>("btn-save")?.RegisterCallback<ClickEvent>(_ => SaveSource());
            root.Q<Button>("btn-compile")?.RegisterCallback<ClickEvent>(_ => CompileAndGenerate());
            _btnFoldAll = root.Q<Button>("btn-fold-all");
            _btnFoldAll?.RegisterCallback<ClickEvent>(_ => ToggleFoldAll());

            // Ensure editor panel grows correctly to fill layout space
            if (_panelEditor != null)
            {
                _panelEditor.style.flexGrow  = 1f;
                _panelEditor.style.flexShrink = 1f;
                _panelEditor.style.flexBasis = 0f;
            }

            _codeField = new TextField
            {
                multiline = true,
                isDelayed = false,
                style     =
                {
                    flexGrow                = new StyleFloat(1f),
                    flexBasis               = new StyleLength(0f),
                    flexShrink              = new StyleFloat(1f),
                    minHeight               = new StyleLength(0f),
                    backgroundColor         = new StyleColor(new Color(0.031f, 0.047f, 0.078f)),
                    color                   = new StyleColor(new Color(0.91f, 0.93f, 0.96f)),
                    unityFontStyleAndWeight = new StyleEnum<FontStyle>(FontStyle.Normal),
                    fontSize                = new StyleLength(12),
                    whiteSpace              = new StyleEnum<WhiteSpace>(WhiteSpace.NoWrap),
                    paddingTop              = new StyleLength(12),
                    paddingLeft             = new StyleLength(12),
                },
            };

            // A multiline TextField only gets its ScrollView-based layout once its vertical scroller
            // visibility is set, and it starts out Hidden. Without the layout the field never scrolls
            // with the mouse wheel or two fingers (only moving the caret scrolls), and a long file just
            // runs off the bottom. This has to happen now, before the colour overlay attaches in
            // InitializeLspIntegration below: the switch re-parents the field's inner text element.
            EnableCodeFieldScroller(_codeField);

            _codeField.RegisterValueChangedCallback(OnCodeFieldValueChanged);

            if (!string.IsNullOrEmpty(_sourceText))
                _codeField.SetValueWithoutNotify(_sourceText);

            _panelEditor?.Add(_codeField);

            // Configure internal ScrollView to enable scrolling and active scrollers
            var codeScrollView = _codeField.Q<ScrollView>();
            if (codeScrollView != null)
            {
                codeScrollView.style.flexGrow            = 1f;
                codeScrollView.style.flexShrink          = 1f;
                codeScrollView.style.flexBasis           = 0f;
                codeScrollView.verticalScrollerVisibility   = ScrollerVisibility.Auto;
                codeScrollView.horizontalScrollerVisibility = ScrollerVisibility.Auto;
            }

            ConstrainPanelHeights();
            InstallCopyAffordances();

            InitializeLspIntegration();
        }

        // ── Tab management ────────────────────────────────────────────────────

        private void ShowTab(int index)
        {
            _activeTab = index;

            SetTabActive(_tabExplorer,  index == 0);
            SetTabActive(_tabEditor,    index == 1);
            SetTabActive(_tabTemplates, index == 2);
            SetTabActive(_tabSearch,    index == 3);

            SetPanelVisible(_panelExplorer,  index == 0);
            SetPanelVisible(_panelEditor,    index == 1);
            SetPanelVisible(_panelTemplates, index == 2);
            SetPanelVisible(_panelSearch,    index == 3);

            if (index == 0 && !string.IsNullOrEmpty(_sourceText))
                RebuildExplorer();

            if (index == 3)
            {
                FocusSearchField();

                // Files may have changed since the last search, so a standing query is run again.
                if (_searchField != null && (SearchFilesMode || !string.IsNullOrEmpty(_searchField.value)))
                    ScheduleSearch();
            }

            RefreshFoldAllButton();
        }

        private static void SetTabActive(VisualElement? tab, bool active)
        {
            if (tab == null) return;
            if (active) tab.AddToClassList("mdix-tab--active");
            else        tab.RemoveFromClassList("mdix-tab--active");
        }

        private static void SetPanelVisible(VisualElement? panel, bool visible)
        {
            if (panel == null) return;
            panel.style.display = visible
                ? new StyleEnum<DisplayStyle>(DisplayStyle.Flex)
                : new StyleEnum<DisplayStyle>(DisplayStyle.None);
        }

        // ── Asset loading ─────────────────────────────────────────────────────

        private void LoadAsset(MdixAsset asset)
        {
            // A different file has different sections; don't carry the old fold state over.
            if (!string.Equals(_currentPath, asset.ProjectRelativePath, StringComparison.Ordinal))
            {
                _foldedSections.Clear();
                _knownFoldKeys.Clear();
            }

            _currentAsset = asset;
            _currentPath  = asset.ProjectRelativePath;
            _sourceText   = asset.RawSource;
            _isDirty      = false;

            if (_fileLabel != null)
                _fileLabel.text = Path.GetFileName(_currentPath);

            // Without notify: loading a file is not an edit (it used to flag the file dirty).
            if (_codeField != null)
                _codeField.SetValueWithoutNotify(_sourceText);

            EditorPrefs.SetString(PrefKeyLastPath, _currentPath);

            Compile();
            NotifyLspDocumentOpened();
        }

        // ── Compile / parse ───────────────────────────────────────────────────

        /// <summary>Compiles the buffer and reports it in the status line. True when it compiled.</summary>
        private bool Compile()
        {
            _lastCompileError = null;

            if (string.IsNullOrEmpty(_sourceText)) return true; // nothing to compile

            var result = Dix.LoadStr(_sourceText);

            if (result.IsFailure)
            {
                _lastCompileError = result.Error.Message;

                var hint = ContainsEditorColourTags(_sourceText)
                    ? "  (the text contains <color=#…> tags — if you didn't write them, use MidManStudio ▸ MDIX Language Server ▸ Strip Editor Colour Tags)"
                    : string.Empty;

                SetStatus($"✗  {_lastCompileError}{hint}", error: true);
                UpdateStatusBar(false, 0, 0, 0);
                return false;
            }

            using var db = result.SuccessResult;

            var entryCount = db.EntryCount;
            int flatCount, tableCount;
            CountTopLevel(db, out flatCount, out tableCount);

            SetStatus($"✓  0 errors", error: false);
            UpdateStatusBar(true, entryCount, flatCount, tableCount);

            if (_activeTab == 0)
                RebuildExplorer(db);

            // Compiling only parses the text; it does not write it anywhere. It used to clear the
            // dirty flag here, so edits that were merely compiled were dropped silently on close.
            return true;
        }

        private string? _lastCompileError;

        /// <summary>
        /// The Compile button. Compiles the buffer; and when the file declares @DLM compression or
        /// encryption, also writes its .mdix.enc and .mdix.key beside it (and gitignores the key).
        /// Saving or opening a file only ever parses it: a new key is made only when you press this,
        /// because every compile generates a different key.
        /// </summary>
        private void CompileAndGenerate()
        {
            if (!Compile()) return;
            if (!MdixEncryption.DeclaresDlmOutput(_sourceText)) return;

            if (string.IsNullOrEmpty(_currentPath))
            {
                SetStatus("✓  Compiles. Save the file, then press Compile again to write the .enc and .key.",
                    error: false);
                return;
            }

            // The .enc is built from the file on disk, so write the buffer out first.
            if (_isDirty)
            {
                SaveSource();
                if (_isDirty) return; // the save failed; SaveSource already said why
            }

            var outcome = MdixEncryption.Generate(_currentPath);
            SetStatus((outcome.Success ? "✓  " : "✗  ") + outcome.Message, error: !outcome.Success);

            if (outcome.Success && outcome.Generated)
            {
                Debug.Log(
                    "[MDIX] " + outcome.Message + "\n" +
                    "  " + outcome.EncPath + "\n  " + outcome.KeyPath + "\n" +
                    (string.IsNullOrEmpty(outcome.GitIgnoreNote) ? string.Empty : "  " + outcome.GitIgnoreNote + "\n") +
                    "  Ship the .enc. Never ship the .key: provide it from your own code with MdixKeys.Provide.");
            }
            else if (!outcome.Success)
            {
                Debug.LogError("[MDIX] Could not write the encrypted file: " + outcome.Message);
            }
        }

        /// <summary>
        /// After a successful write: compile (which refreshes the status bar and the Explorer) and
        /// say so honestly. Save used to print "Saved" and stop, so the Explorer kept showing the
        /// previous version and a file that no longer compiled looked fine.
        /// </summary>
        private void ReportSaved()
        {
            if (Compile())
                SetStatus("✓  Saved — 0 errors", error: false);
            else
                SetStatus($"✗  Saved, but it does not compile: {_lastCompileError}", error: true);
        }

        // ── Explorer ──────────────────────────────────────────────────────────

        private void RebuildExplorer()
        {
            if (string.IsNullOrEmpty(_sourceText)) return;

            var result = Dix.LoadStr(_sourceText);
            if (result.IsFailure) return;

            using var db = result.SuccessResult;
            RebuildExplorer(db);
        }

        private void RebuildExplorer(MdixDatabase db) => BuildExplorer(db);

        private static Label MakeSectionHeader(string text)
        {
            return new Label(text)
            {
                style =
                {
                    backgroundColor         = new StyleColor(new Color(0.051f, 0.071f, 0.125f)),
                    color                   = new StyleColor(new Color(0.478f, 0.596f, 0.769f)),
                    fontSize                = new StyleLength(10),
                    unityFontStyleAndWeight = new StyleEnum<FontStyle>(FontStyle.Bold),
                    paddingTop              = new StyleLength(4),
                    paddingBottom           = new StyleLength(4),
                    paddingLeft             = new StyleLength(12),
                    borderBottomWidth       = new StyleFloat(1f),
                    borderBottomColor       = new StyleColor(new Color(0.102f, 0.149f, 0.251f)),
                }
            };
        }

        private static VisualElement MakeKeyValueRow(
            MdixDatabase db,
            string       fullPath,
            string?      labelOverride = null)
        {
            var row = new VisualElement();
            row.AddToClassList("mdix-kv-row");

            var valueType  = db.GetValueType(fullPath);
            var displayKey = labelOverride ?? fullPath;

            var keyLabel = new Label(displayKey);
            keyLabel.AddToClassList("mdix-kv__key");

            var valueStr   = GetValueDisplayString(db, fullPath, valueType);
            var valueLabel = new Label(valueStr);
            valueLabel.AddToClassList("mdix-kv__value");

            var typeLabel = new Label(valueType.ToString().ToLower());
            typeLabel.AddToClassList("mdix-kv__type");

            // Apply type-specific styling classes.
            switch (valueType)
            {
                case MdixValueType.Enum:
                    typeLabel.AddToClassList("mdix-kv__type--enum");
                    break;
                case MdixValueType.Bool:
                    typeLabel.AddToClassList("mdix-kv__type--bool");
                    break;
                case MdixValueType.String:
                case MdixValueType.Date:
                case MdixValueType.Timestamp:
                    typeLabel.AddToClassList("mdix-kv__type--string");
                    break;
                // Int, Long, Float, Double use the default blue mdix-kv__type style.
            }

            row.Add(keyLabel);
            row.Add(valueLabel);
            row.Add(typeLabel);

            return row;
        }

        private static string GetValueDisplayString(
            MdixDatabase  db,
            string        path,
            MdixValueType valueType)
        {
            return valueType switch
            {
                MdixValueType.String    => db.GetString(path).UnwrapOr(string.Empty),
                MdixValueType.Int       => db.GetInt(path).UnwrapOr(0).ToString(),
                // Long values displayed with L suffix to make the type obvious in the Explorer.
                MdixValueType.Long      => db.GetLong(path).UnwrapOr(0L).ToString() + "L",
                MdixValueType.Float     => db.GetFloat(path).UnwrapOr(0f)
                                              .ToString("G", System.Globalization.CultureInfo.InvariantCulture) + "f",
                MdixValueType.Double    => db.GetDouble(path).UnwrapOr(0d)
                                              .ToString("G", System.Globalization.CultureInfo.InvariantCulture),
                MdixValueType.Bool      => db.GetBool(path).UnwrapOr(false).ToString().ToLower(),
                MdixValueType.Enum      =>
                    $"{db.GetEnumName(path).UnwrapOr("?")}." +
                    $"{db.GetEnumField(path).UnwrapOr("?")}",
                MdixValueType.HexColor  => db.GetString(path).UnwrapOr("#?"),
                MdixValueType.Date      => db.GetString(path).UnwrapOr("?"),
                MdixValueType.Timestamp => db.GetString(path).UnwrapOr("?"),
                MdixValueType.Null      => "null",
                MdixValueType.Array     => "[array]",
                MdixValueType.Object    => "{object}",
                MdixValueType.Tuple     => "(tuple)",
                _                       => "?",
            };
        }

        // ── Templates panel ───────────────────────────────────────────────────

        private void BuildTemplatesPanel()
        {
            if (_panelTemplates == null) return;

            var scroll = new ScrollView(ScrollViewMode.Vertical) { style = { flexGrow = 1 } };

            var header = new Label("Choose a template to create a new .mdix file")
            {
                style =
                {
                    color         = new StyleColor(new Color(0.478f, 0.596f, 0.769f)),
                    fontSize      = new StyleLength(12),
                    paddingTop    = new StyleLength(16),
                    paddingLeft   = new StyleLength(16),
                    paddingBottom = new StyleLength(8),
                }
            };
            scroll.Add(header);

            var grid = new VisualElement();
            grid.AddToClassList("mdix-template-grid");

            var templateDefs = new (string title, string desc, string content)[]
            {
                ("Blank",            "Empty file with @CONFIG stub",                          Templates.Blank),
                ("Game Enemies",     "Enemy array with AI enum and @QUICKFUNCS formula",     Templates.GameEnemies),
                ("Inventory Items",  "Item array with type and rarity enums",                Templates.InventoryItems),
                ("App Config",       "Environment enum, log level, server block",            Templates.AppConfig),
                ("Server Config",    "Multi-environment with @QUICKFUNCS",                   Templates.MultiEnvServer),
                ("Encrypted Secrets","API keys with @DLM encryption",                        Templates.EncryptedSecrets),
                ("Player Save",      "Save game data with position and flags",               Templates.PlayerSave),
            };

            foreach (var (title, desc, content) in templateDefs)
            {
                var card = new VisualElement();
                card.AddToClassList("mdix-template-card");

                var cardTitle = new Label(title);
                cardTitle.AddToClassList("mdix-template-card__title");

                var cardDesc = new Label(desc);
                cardDesc.AddToClassList("mdix-template-card__desc");

                card.Add(cardTitle);
                card.Add(cardDesc);

                var capturedContent = content;
                var capturedTitle   = title;

                card.RegisterCallback<ClickEvent>(_ =>
                    CreateFromTemplate(capturedTitle, capturedContent));

                grid.Add(card);
            }

            scroll.Add(grid);
            _panelTemplates.Add(scroll);
        }

        private static void CreateFromTemplate(string title, string content)
        {
            var defaultName = title.ToLower().Replace(" ", "_");
            var folder      = AssetDatabase.GetAssetPath(Selection.activeObject);

            if (string.IsNullOrEmpty(folder) || !Directory.Exists(folder))
                folder = "Assets";

            var path = AssetDatabase.GenerateUniqueAssetPath(
                $"{folder}/{defaultName}.mdix");

            File.WriteAllText(path, content);
            AssetDatabase.Refresh();

            var asset = AssetDatabase.LoadAssetAtPath<MdixAsset>(path);
            if (asset != null)
                Selection.activeObject = asset;
        }

        // ── Save ──────────────────────────────────────────────────────────────

        private void SaveSource()
        {
            // A scratch document (typed straight into the Editor tab) has no file yet: Save As.
            if (string.IsNullOrEmpty(_currentPath))
            {
                var newPath = PromptAndWriteNewFile();
                if (newPath != null)
                    AdoptSavedPath(newPath);

                return;
            }

            try
            {
                File.WriteAllText(_currentPath, _sourceText);
                AssetDatabase.ImportAsset(_currentPath);
                _isDirty = false;
                ReportSaved();
            }
            catch (Exception ex)
            {
                SetStatus($"✗  Save failed: {ex.Message}", error: true);
            }
        }

        /// <summary>
        /// Asks where an unsaved (scratch) document should live and writes it there. Returns the
        /// project-relative path, or null if the person cancelled or the write failed. Leaves the
        /// window's own state alone, so it is also safe to call while the window is closing.
        /// </summary>
        private string? PromptAndWriteNewFile()
        {
            var path = EditorUtility.SaveFilePanelInProject(
                "Save MDIX file", "untitled", "mdix",
                "Choose where to save this .mdix file inside the project.");

            if (string.IsNullOrEmpty(path)) return null; // cancelled

            try
            {
                File.WriteAllText(path, _sourceText);
                AssetDatabase.ImportAsset(path);
                return path;
            }
            catch (Exception ex)
            {
                SetStatus($"✗  Save failed: {ex.Message}", error: true);
                return null;
            }
        }

        /// <summary>Points the window at the file a scratch document was just saved as.</summary>
        private void AdoptSavedPath(string path)
        {
            _currentAsset = AssetDatabase.LoadAssetAtPath<MdixAsset>(path);
            _currentPath  = path;
            _isDirty      = false;

            if (_fileLabel != null)
                _fileLabel.text = Path.GetFileName(path);

            EditorPrefs.SetString(PrefKeyLastPath, path);

            NotifyLspDocumentOpened();  // the server drops the untitled document and opens this file
            ReportSaved();              // compiles: refreshes the status bar (file name included) and the Explorer
        }

        // ── Status helpers ────────────────────────────────────────────────────

        private void SetStatus(string text, bool error)
        {
            if (_statusLabel == null) return;
            _statusLabel.text = text;
            _statusLabel.EnableInClassList("mdix-status--error", error);
        }

        private void UpdateStatusBar(
            bool parsed, int entryCount, int flatCount, int tableCount)
        {
            if (_sbCompiled != null)
            {
                _sbCompiled.text = parsed ? "● Compiled" : "● Not compiled";
                _sbCompiled.EnableInClassList("mdix-statusbar__item--ok",    parsed);
                _sbCompiled.EnableInClassList("mdix-statusbar__item--error", !parsed);
            }

            if (_sbEntries  != null) _sbEntries.text  = $"{entryCount} entries";
            if (_sbFlatKeys != null) _sbFlatKeys.text = $"{flatCount} flat keys";
            if (_sbTables   != null) _sbTables.text   = $"{tableCount} table keys";
            if (_sbPath     != null) _sbPath.text     = Path.GetFileName(_currentPath);
        }

        // ── OnEnable / OnDisable ──────────────────────────────────────────────

        private void OnEnable()
        {
            if (_currentAsset == null)
            {
                var lastPath = EditorPrefs.GetString(PrefKeyLastPath, string.Empty);
                if (!string.IsNullOrEmpty(lastPath))
                {
                    var asset = AssetDatabase.LoadAssetAtPath<MdixAsset>(lastPath);
                    if (asset != null)
                        LoadAsset(asset);
                }
            }
        }

        private void OnDisable()
        {
            if (_isDirty)
            {
                var scratch = string.IsNullOrEmpty(_currentPath);
                var name    = scratch ? "Untitled" : Path.GetFileName(_currentPath);

                if (EditorUtility.DisplayDialog(
                    "Unsaved Changes",
                    $"'{name}' has unsaved changes. Save before closing?",
                    "Save", "Discard"))
                {
                    if (scratch)
                    {
                        // Only write the file: the window is going away, so don't rebind its UI.
                        var saved = PromptAndWriteNewFile();
                        if (saved != null)
                            EditorPrefs.SetString(PrefKeyLastPath, saved);
                    }
                    else
                    {
                        SaveSource();
                    }
                }
            }

            ShutdownLspIntegration();
        }
    }
}
