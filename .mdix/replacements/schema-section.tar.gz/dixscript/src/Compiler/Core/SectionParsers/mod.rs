
//! Section parsers for different DixScript sections

pub mod enums_section_parser;
pub mod dlm_section_parser;
pub mod security_section_parser;
pub mod raw_section_parser;
pub mod schema_section_parser;
pub mod imports_section_parser;
mod data_section_parser;
mod quickfuncs_section_parser;

pub use enums_section_parser::EnumsSectionParser;
pub use dlm_section_parser::DlmSectionParser;
pub use security_section_parser::SecuritySectionParser;
pub use raw_section_parser::RawSectionParser;
pub use schema_section_parser::SchemaSectionParser;
pub use imports_section_parser::ImportsSectionParser;
pub use quickfuncs_section_parser::QuickFuncsSectionParser;
pub use data_section_parser::DataSectionParser;
