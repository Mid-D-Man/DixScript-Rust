// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/dixscript/compiler.md (referenced from the Compiler modules it
// benchmarks)
// ============================================================================
//! Benchmarks for the `@RAW` section: lexer-level content-block scanning
//! throughput across payload sizes, and full-pipeline (tokenize -> parse ->
//! semantic analysis) overhead as the number of `@RAW` blocks in a file
//! grows -- the analyzer's cross-block uniqueness checks are the one part
//! of this feature whose cost scales with block count rather than payload
//! size, so that's tracked separately from raw scanning throughput.
//!
//! All input is generated inline -- no filesystem reads -- so this
//! benchmark works correctly in CI without any fixture files present.

use dixscript::Compiler::Core::Config::OperationalSettings;
use dixscript::Compiler::Core::Tokenizer::Tokenizer;
use dixscript::Runtime::DixLoader;
use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use std::time::Duration;

// ── Input generators ──────────────────────────────────────────────────────────

fn generate_raw_block(id_suffix: usize, payload_bytes: usize) -> String {
    let payload: String = (0..payload_bytes).map(|i| (b'a' + (i % 26) as u8) as char).collect();
    format!(
        "@RAW(\n  meta_data -> {{ id = \"asset_{id_suffix}\", format = \"BIN\", size = {payload_bytes} }}\n  using -> {{ compression = \"none\" }}\n  content -> {{ ---tag_{id_suffix}--- {payload} ---tag_{id_suffix}--- }}\n)\n"
    )
}

fn generate_single_raw_input(payload_bytes: usize) -> String {
    generate_raw_block(0, payload_bytes)
}

fn generate_multi_raw_input(num_blocks: usize, payload_bytes_each: usize) -> String {
    let mut input = String::with_capacity(num_blocks * (payload_bytes_each + 150));
    for i in 0..num_blocks {
        input.push_str(&generate_raw_block(i, payload_bytes_each));
    }
    input
}

// ── Lexer-level: content-block scanning throughput ──────────────────────────

fn raw_lexer_scan_benchmark(c: &mut Criterion) {
    let mut group = c.benchmark_group("raw_section_lexer_scan");
    let settings = OperationalSettings::default();

    // Payload sizes chosen to bracket realistic asset-hint sizes. Pure
    // memchr-based scanning, no parsing/analysis -- stays fast even at the
    // top end, so this group doesn't need the tiered scaling the full-
    // pipeline group below does.
    for &payload_size in &[256usize, 4_096, 65_536, 262_144] {
        group.measurement_time(Duration::from_secs(8));
        let input = generate_single_raw_input(payload_size);
        group.throughput(Throughput::Bytes(input.len() as u64));
        group.bench_with_input(
            BenchmarkId::new("payload_bytes", payload_size),
            &input,
            |b, input| {
                b.iter(|| {
                    let t = Tokenizer::new(black_box(input), &settings);
                    black_box(t.tokenize())
                });
            },
        );
    }

    group.finish();
}

// ── Full pipeline: tokenize -> parse -> semantic analysis ───────────────────
//
// Tracks how `raw_section_analyzer.rs`'s cross-block id/tag uniqueness
// checks (FxHashMap-based, see that file) actually scale as block count
// grows -- separate concern from raw scanning throughput above, which
// only ever looks at one block. Each iteration runs the FULL pipeline
// (tokenize -> parse each block via its own RawSectionParser instance ->
// semantic analysis -> the enhancer's whole-AST clone -> value resolution),
// not just scanning, so cost per iteration is real compiler work, not a
// memchr scan. Sample size and measurement time are scaled down for the
// larger block counts, same philosophy stress_test_benchmark.rs already
// uses for its heaviest cases -- fewer, longer-observed samples instead of
// criterion's default 100 samples at whatever time that takes.
fn raw_full_pipeline_benchmark(c: &mut Criterion) {
    let mut group = c.benchmark_group("raw_section_full_pipeline");

    // (block_count, sample_size, measurement_time_secs)
    for &(num_blocks, sample_size, measurement_secs) in
        &[(10usize, 30usize, 8u64), (50, 15, 10), (150, 10, 15)]
    {
        group.sample_size(sample_size);
        group.measurement_time(Duration::from_secs(measurement_secs));

        let input = generate_multi_raw_input(num_blocks, 64);
        group.throughput(Throughput::Elements(num_blocks as u64));
        group.bench_with_input(
            BenchmarkId::new("blocks", num_blocks),
            &input,
            |b, input| {
                b.iter(|| {
                    let loader = DixLoader::new();
                    black_box(
                        loader
                            .compile_to_resolved_ast_from_str(black_box(input), "raw_bench")
                            .expect("generated input should always compile"),
                    )
                });
            },
        );
    }

    group.finish();
}

criterion_group!(benches, raw_lexer_scan_benchmark, raw_full_pipeline_benchmark);
criterion_main!(benches);
